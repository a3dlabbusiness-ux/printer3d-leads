"""
Entrypoint principale del sistema (interfaccia web / PWA per iPhone).

Avvia:
1. il server web FastAPI (login + dashboard, servito anche come PWA installabile);
2. uno scheduler in background che:
   - processa la coda email rispettando i limiti configurati;
   - controlla eventuali risposte via IMAP (se configurato).

Avvio:
    python web_main.py

Poi apri da Safari sul telefono: http://<ip-del-pc>:8000
(vedi README per come installarla sulla schermata Home e per l'accesso da remoto)
"""
from __future__ import annotations

import logging

import uvicorn
from apscheduler.schedulers.background import BackgroundScheduler

from app.config import settings
from app.database.db import get_session, init_db
from app.email_sender.queue_worker import process_queue_once
from app.logging_config import setup_logging
from app.reply_checker.imap_checker import imap_configured, process_replies

logger = logging.getLogger(__name__)

QUEUE_CHECK_INTERVAL_SECONDS = 60
REPLY_CHECK_INTERVAL_SECONDS = 300


def job_process_queue() -> None:
    try:
        process_queue_once()
    except Exception:
        logger.exception("Errore nel job di elaborazione coda email")


def job_check_replies() -> None:
    if not imap_configured():
        return
    try:
        with get_session() as session:
            process_replies(session)
    except Exception:
        logger.exception("Errore nel job di controllo risposte IMAP")


def start_scheduler() -> BackgroundScheduler:
    scheduler = BackgroundScheduler(timezone="UTC")
    scheduler.add_job(job_process_queue, "interval", seconds=QUEUE_CHECK_INTERVAL_SECONDS, next_run_time=None)
    scheduler.add_job(job_check_replies, "interval", seconds=REPLY_CHECK_INTERVAL_SECONDS)
    scheduler.start()
    return scheduler


def main() -> None:
    setup_logging()
    logger.info("Inizializzazione database...")
    init_db()

    if not settings.web_admin_password:
        logger.warning(
            "ATTENZIONE: WEB_ADMIN_PASSWORD non è impostata nel file .env. "
            "La web-app rifiuterà qualsiasi login finché non la configuri."
        )

    logger.info("Avvio scheduler in background (coda email, controllo risposte)...")
    start_scheduler()

    logger.info(
        "Avvio server web su http://%s:%d — apri questo indirizzo da Safari sul telefono.",
        settings.web_host, settings.web_port,
    )
    uvicorn.run("app.web.api:app", host=settings.web_host, port=settings.web_port, log_level="info")


if __name__ == "__main__":
    main()
