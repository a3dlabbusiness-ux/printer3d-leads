# Printer3D Leads — Web App per iPhone

Sistema per trovare potenziali clienti B2B per la tua attività di stampa 3D
(bar, ristoranti, hotel, negozi, ecc.), analizzarli, e proporti una bozza email
tramite una **web-app installabile sulla schermata Home del tuo iPhone**.
Tu decidi manualmente se approvare, modificare, saltare o bloccare ogni
contatto — nessuna email parte mai senza la tua approvazione esplicita.

> Nota: il progetto include anche un vecchio bot Telegram (`legacy_telegram_main.py`),
> tenuto per chi preferisce quell'interfaccia, ma **l'interfaccia principale ora è
> la web-app** descritta in questo README (`web_main.py`).

---

## 1. Cosa fa il software

1. Apri l'app dalla schermata Home del tuo iPhone (si installa in 1 minuto, sezione 6).
2. Nella scheda "Cerca" imposti città, categoria e numero massimo di risultati.
3. Il sistema trova le attività (da un provider a tua scelta: CSV o Google Places),
   controlla se sono già in database o in blacklist, e cerca — solo se pubblicamente
   disponibile — un'email di contatto sul sito.
4. Nella scheda "In attesa" vedi ogni nuovo lead con i suoi dati e una bozza email,
   con i pulsanti: Approva, Salva modifica, Salta, Blacklist, Apri sito.
5. Solo se premi Approva, l'email entra nella coda di invio.
6. Un worker interno invia le email rispettando i limiti che imposti (quante al
   giorno, quante all'ora, in quali orari/giorni).
7. Nella scheda "Statistiche" vedi tutto lo storico e i tassi di conversione.

---

## 2. Cosa devi installare

- **Python 3.11 o superiore** (verifica con `python3 --version`)
- Un editor di testo qualsiasi per modificare `.env`

Tutto il resto (librerie Python) si installa con un comando, vedi sezione 5.

---

## 3. Scegli una password per la web-app

Al posto del bot Telegram, ora l'accesso è protetto da una password che scegli
tu. Pensane una robusta (es. una frase di 4-5 parole) — la userai per accedere
dall'iPhone. La inserirai nel file `.env` al passo successivo.

---

## 4. Configura il file `.env`

1. Copia il file di esempio:
   ```
   cp .env.example .env
   ```
   (su Windows: `copy .env.example .env`)
2. Apri `.env` con un editor di testo e imposta almeno:
   ```
   WEB_ADMIN_PASSWORD=la-password-che-hai-scelto
   ```
3. Il file `.env` **non va mai condiviso né caricato online**: contiene i tuoi segreti.

Di default il sistema funziona già con:
- ricerca lead da un file CSV di esempio (nessuna API a pagamento richiesta)
- email generate con un modello di testo (nessuna AI a pagamento richiesta)

### Provider di ricerca lead

Di default (`LEAD_PROVIDER=csv`) il sistema legge i lead da un file CSV che
prepari tu (nessuna API key richiesta) — usa come base
`data/leads_import.example.csv`, copialo in `data/leads_import.csv` e
compilalo con le tue attività (vedi formato colonne nel file stesso).

Per usare la ricerca automatica su Google Maps invece:
```
LEAD_PROVIDER=google_places
GOOGLE_PLACES_API_KEY=la-tua-chiave
```
⚠️ **Google Places API è un servizio a pagamento** oltre una soglia gratuita
mensile. Attivalo solo se vuoi usarlo consapevolmente (Google Cloud Console →
abilita "Places API (New)" → crea una API key).

### Intelligenza artificiale (opzionale)

Di default (`AI_PROVIDER=template`) le email vengono generate con un template
testuale, senza bisogno di alcuna API key. Per usare Claude per generare bozze
email più naturali:
```
AI_PROVIDER=anthropic
AI_API_KEY=la-tua-chiave-anthropic
```
Anche questo è un servizio a pagamento in base all'utilizzo.

### Invio email (SMTP) e rilevamento risposte (IMAP, opzionale)

```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=tuonome@gmail.com
SMTP_PASSWORD=password-per-app
EMAIL_FROM=tuonome@gmail.com
EMAIL_FROM_NAME=Il Tuo Nome Stampa 3D
```
Se usi Gmail, devi generare una **"password per le app"** (non la password
normale): Impostazioni Google → Sicurezza → Verifica in due passaggi →
Password per le app.

Per rilevare automaticamente le risposte (opzionale):
```
IMAP_HOST=imap.gmail.com
IMAP_PORT=993
IMAP_USERNAME=tuonome@gmail.com
IMAP_PASSWORD=password-per-app
```
Se non configuri IMAP, il sistema funziona lo stesso: semplicemente non
rileverà automaticamente le risposte.

---

## 5. Installa le dipendenze e avvia il server

```bash
python3 -m venv .venv
source .venv/bin/activate        # su Windows: .venv\Scripts\activate
pip install -r requirements.txt
python web_main.py
```

Se tutto va bene, vedrai una riga tipo:
```
Avvio server web su http://0.0.0.0:8000 — apri questo indirizzo da Safari sul telefono.
```

Questo terminale deve restare aperto finché vuoi che il sistema sia attivo.
Per fermarlo, premi `Ctrl+C`.

---

## 6. Installa l'app sulla schermata Home dell'iPhone

**Prima cosa da sapere**: il tuo iPhone deve poter "raggiungere" il computer su
cui gira `web_main.py`. Il modo più semplice per iniziare è avere **iPhone e
PC sulla stessa rete Wi-Fi di casa**.

**6a. Trova l'indirizzo IP del tuo computer sulla rete locale:**

- **Mac**: Preferenze di Sistema → Wi-Fi → Dettagli → cerca "Indirizzo IP" (es. `192.168.1.42`)
- **Windows**: apri il prompt e scrivi `ipconfig`, cerca "Indirizzo IPv4"
- **Linux**: nel terminale scrivi `hostname -I`

**6b. Sull'iPhone (stessa rete Wi-Fi):**
1. Apri **Safari** (deve essere Safari, non Chrome, per l'installazione)
2. Vai all'indirizzo: `http://192.168.1.42:8000` (sostituisci con il TUO indirizzo IP)
3. Inserisci la password scelta al passo 3
4. Tocca l'icona "Condividi" (il quadrato con la freccia in su) in basso
5. Scorri e tocca **"Aggiungi alla schermata Home"**
6. Conferma: ora hai un'icona vera sulla tua Home, si apre a schermo intero

---

## 7. Usare l'app da fuori casa (opzionale, quando sei pronto)

Con la sola rete Wi-Fi di casa, l'app funziona solo quando iPhone e PC sono
sulla stessa rete. Per usarla ovunque (es. mentre sei fuori), il modo più
semplice — **gratis e senza bisogno di un server o di un dominio** — è
**Tailscale**: crea una rete privata virtuale tra i tuoi dispositivi.

1. Vai su [tailscale.com/download](https://tailscale.com/download)
2. Installa Tailscale sul tuo PC/Mac (crea un account gratuito, es. con Google)
3. Installa l'app **Tailscale** dall'App Store sul tuo iPhone, accedi con lo stesso account
4. Su ogni dispositivo, Tailscale ti mostra un indirizzo tipo `100.x.x.x` — quello
   del PC è l'indirizzo da usare al posto di `192.168.1.42` nel passo 6b
5. Ora, ovunque tu sia (anche fuori casa, con i dati mobili), potrai raggiungere
   `http://100.x.x.x:8000` dall'iPhone, in modo sicuro e criptato

⚠️ Non esporre `web_main.py` direttamente su internet (es. con il port forwarding
del router) senza aggiungere HTTPS davanti: Tailscale evita questo problema
del tutto, tenendo la connessione privata.

---

## 8. Come fermarlo

Nel terminale dove sta girando `web_main.py`, premi `Ctrl + C`.

---

## 9. Come fare backup del database

Il database è un singolo file SQLite in `data/leads.db`. Per fare un backup
basta copiarlo:

```bash
cp data/leads.db data/leads_backup_$(date +%Y%m%d).db
```

---

## 10. Come modificare il limite email

Apri `.env` e modifica, ad esempio:

```
MAX_EMAILS_PER_DAY=30
MAX_EMAILS_PER_HOUR=8
MIN_SECONDS_BETWEEN_EMAILS=300
SENDING_HOUR_START=9
SENDING_HOUR_END=18
SENDING_DAYS=0,1,2,3,4
```

Riavvia il programma perché le modifiche abbiano effetto. In alternativa,
puoi mettere in pausa temporaneamente gli invii dalla scheda "Impostazioni"
della web-app, senza perdere la coda.

---

## 11. Come cambiare città/categoria

Nessuna modifica al codice necessaria: apri la scheda "Cerca" nella web-app,
inserisci città, categoria e numero massimo, e tocca "Avvia ricerca".

---

## 12. Le schede della web-app

| Scheda | Cosa fa |
|---|---|
| In attesa | Rivedi i nuovi lead trovati: Approva / Salva modifica / Salta / Blacklist |
| Cerca | Avvia una nuova ricerca (città, categoria, numero massimo, parole chiave) |
| Coda | Email attualmente in coda di invio |
| Statistiche | Statistiche generali e per categoria |
| Impostazioni | Impostazioni correnti, pausa/riattiva invii, logout |

---

## 13. Eseguire i test

```bash
source .venv/bin/activate
pytest -v
```

I test coprono: deduplicazione, cambio stato lead, coda email, limiti
giornalieri/orari, blacklist, autenticazione web, parsing/validazione email,
ed endpoint della web API (login, lista lead in attesa, approvazione).

**Nota:** questi test sono stati scritti e controllati sintatticamente, ma
non sono stati eseguiti end-to-end in questa sessione perché l'ambiente in
cui è stato generato il codice non aveva accesso a internet per installare
le librerie (SQLAlchemy, FastAPI, ecc.). Eseguili tu con i comandi sopra al
primo avvio: se qualcosa non passa, incollami l'errore e lo correggo subito.

---

## 14. Struttura del progetto

```
printer3d_leads/
├── web_main.py                  # entrypoint principale (web-app + scheduler)
├── legacy_telegram_main.py       # entrypoint legacy (bot Telegram, opzionale)
├── app/
│   ├── config.py                # lettura configurazione da .env
│   ├── logging_config.py
│   ├── database/
│   │   ├── models.py             # tabelle: Lead, EmailDraft, EmailMessage,
│   │   │                         # Approval, Blacklist, Source, Campaign,
│   │   │                         # WebSession, ecc.
│   │   └── db.py
│   ├── leads/
│   │   ├── providers/            # base.py, csv_provider.py, google_places_provider.py
│   │   ├── discovery.py          # orchestratore ricerca + analisi sito
│   │   └── site_analyzer.py      # estrazione email pubblica reale dal sito
│   ├── ai/                      # provider AI (template / anthropic)
│   ├── services/                # dedup, lead_service, queue_service, stats_service
│   ├── email_sender/             # smtp_sender.py, queue_worker.py
│   ├── web/                     # ⭐ web-app (interfaccia principale)
│   │   ├── api.py                 # endpoint FastAPI
│   │   ├── security.py            # login/sessione
│   │   └── static/                # index.html, app.js, style.css, manifest.json, icone
│   ├── telegram_bot/             # bot.py, handlers.py (legacy, opzionale)
│   └── reply_checker/            # imap_checker.py
├── tests/
├── data/                        # database SQLite (creato al primo avvio)
├── logs/                        # log applicativi
├── .env.example
├── .gitignore
├── requirements.txt
└── requirements-telegram-optional.txt   # solo se vuoi ANCHE il bot Telegram
```

---

## 15. Compliance — cosa questo software NON fa (di proposito)

- Non invia mai email senza la tua approvazione esplicita.
- Non inventa MAI indirizzi email: usa solo email trovate pubblicamente
  (mailto/testo del sito) o fornite da API autorizzate.
- Non usa tecniche di spoofing, non aggira filtri antispam, non ruota
  account per bypassare limiti.
- Rispetta blacklist e opt-out: un'attività bloccata non viene più proposta.
- Ogni email include un testo di opt-out configurabile.

---

## 16. Se preferisci ancora Telegram (opzionale)

Il vecchio bot Telegram è ancora nel progetto e funziona:

```bash
pip install -r requirements-telegram-optional.txt
python legacy_telegram_main.py
```

Configuralo con `TELEGRAM_BOT_TOKEN` e `TELEGRAM_ADMIN_ID` in `.env` (vedi
i commenti nel file `.env.example`). Puoi usare l'uno o l'altro, o
volendo entrambi (condividono lo stesso database).

---

## 17. Sicurezza della web-app — cosa sapere

- La password (`WEB_ADMIN_PASSWORD`) è l'unica barriera d'accesso: scegline
  una robusta e non condividerla.
- L'app è pensata per uso **personale**, su rete fidata (casa, o Tailscale).
  Non esporla direttamente su internet pubblico senza HTTPS davanti.
- La sessione resta attiva sul telefono per `WEB_SESSION_HOURS` (default 30
  giorni) così non devi reinserire la password ogni volta: se il telefono
  viene smarrito, cambia subito la password in `.env` e riavvia il server
  (questo invalida automaticamente le sessioni salvate al riavvio del database,
  oppure elimina manualmente le righe dalla tabella `web_sessions`).

