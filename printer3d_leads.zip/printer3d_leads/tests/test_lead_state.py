from app.database.models import EmailDraft, Lead, LeadStatus, Source
from app.services import queue_service


def _make_lead_with_draft(session, email="cliente@esempio.it"):
    source = Source(name="csv")
    session.add(source)
    session.flush()
    lead = Lead(
        name="Bar Test", category="bar", city="Catania",
        email=email, status=LeadStatus.PENDING_REVIEW, source=source,
    )
    session.add(lead)
    session.flush()
    session.add(EmailDraft(lead_id=lead.id, subject="Oggetto", body="Corpo email", is_active=True))
    session.flush()
    return lead


def test_lead_starts_pending_review(db_session):
    lead = _make_lead_with_draft(db_session)
    assert lead.status == LeadStatus.PENDING_REVIEW


def test_enqueue_approved_lead_changes_status_to_queued(db_session):
    lead = _make_lead_with_draft(db_session)
    message = queue_service.enqueue_approved_lead(db_session, lead)
    assert lead.status == LeadStatus.QUEUED
    assert message.status == "QUEUED"
    assert message.to_email == "cliente@esempio.it"


def test_enqueue_without_email_raises(db_session):
    lead = _make_lead_with_draft(db_session, email=None)
    lead.email = None
    db_session.flush()
    import pytest
    with pytest.raises(ValueError):
        queue_service.enqueue_approved_lead(db_session, lead)


def test_enqueue_without_draft_raises(db_session):
    source = Source(name="csv")
    db_session.add(source)
    db_session.flush()
    lead = Lead(name="Bar Senza Bozza", email="x@example.it", status=LeadStatus.PENDING_REVIEW, source=source)
    db_session.add(lead)
    db_session.flush()

    import pytest
    with pytest.raises(ValueError):
        queue_service.enqueue_approved_lead(db_session, lead)
