from app.services import dedup


def test_add_and_check_blacklist_by_domain(db_session):
    dedup.add_to_blacklist(db_session, reason="test", domain="spammer.it")
    db_session.flush()
    assert dedup.is_blacklisted(db_session, domain="spammer.it") is True
    assert dedup.is_blacklisted(db_session, domain="altro.it") is False


def test_add_and_check_blacklist_by_email(db_session):
    dedup.add_to_blacklist(db_session, reason="opt-out", email="Utente@Esempio.it")
    db_session.flush()
    assert dedup.is_blacklisted(db_session, email="utente@esempio.it") is True


def test_add_and_check_blacklist_by_name_address(db_session):
    dedup.add_to_blacklist(db_session, reason="richiesta cliente", name="Bar Mario", address="Via Etnea 5")
    db_session.flush()
    assert dedup.is_blacklisted(db_session, name="Bar Mario", address="Via Etnea 5") is True
    assert dedup.is_blacklisted(db_session, name="Bar Mario", address="Altro indirizzo") is False


def test_blacklist_no_duplicate_entries(db_session):
    dedup.add_to_blacklist(db_session, domain="spammer.it")
    db_session.flush()
    dedup.add_to_blacklist(db_session, domain="spammer.it")
    db_session.flush()

    from app.database.models import Blacklist
    count = db_session.query(Blacklist).filter(Blacklist.identifier_value == "spammer.it").count()
    assert count == 1
