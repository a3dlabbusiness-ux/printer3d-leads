from datetime import datetime, timedelta

from app.database.models import EmailMessage, Lead, LeadStatus, Source
from app.services import queue_service

MONDAY_10AM = datetime(2024, 1, 1, 10, 0, 0)  # 1 gennaio 2024 è un lunedì, ore 10 (dentro la finestra 9-18)
SATURDAY_10AM = datetime(2024, 1, 6, 10, 0, 0)  # sabato: fuori dai giorni consentiti (lun-ven)
MONDAY_7AM = datetime(2024, 1, 1, 7, 0, 0)  # fuori fascia oraria


def _make_lead(session, name="Lead"):
    source = Source(name="csv")
    session.add(source)
    session.flush()
    lead = Lead(name=name, email=f"{name.lower()}@example.it", status=LeadStatus.QUEUED, source=source)
    session.add(lead)
    session.flush()
    return lead


def _add_sent_message(session, lead, sent_at):
    msg = EmailMessage(
        lead_id=lead.id, subject="s", body="b", to_email=lead.email,
        status="SENT", sent_at=sent_at,
    )
    session.add(msg)
    session.flush()
    return msg


def test_can_send_within_window_and_no_prior_sends(db_session):
    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is True


def test_cannot_send_outside_allowed_days(db_session):
    can_send, reason = queue_service.can_send_now(db_session, now=SATURDAY_10AM)
    assert can_send is False
    assert "fascia" in reason or "giorni" in reason


def test_cannot_send_outside_allowed_hours(db_session):
    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_7AM)
    assert can_send is False


def test_daily_limit_enforced(db_session):
    lead = _make_lead(db_session)
    day_start = MONDAY_10AM.replace(hour=1)
    for i in range(10):  # MAX_EMAILS_PER_DAY di default = 10
        _add_sent_message(db_session, lead, day_start + timedelta(minutes=i))

    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is False
    assert "giornaliero" in reason


def test_hourly_limit_enforced(db_session):
    lead = _make_lead(db_session)
    for i in range(5):  # MAX_EMAILS_PER_HOUR di default = 5
        _add_sent_message(db_session, lead, MONDAY_10AM - timedelta(minutes=i * 5))

    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is False
    assert "orario" in reason


def test_min_seconds_between_emails_enforced(db_session):
    lead = _make_lead(db_session)
    _add_sent_message(db_session, lead, MONDAY_10AM - timedelta(seconds=10))  # troppo recente

    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is False


def test_pause_blocks_sending(db_session):
    queue_service.set_paused(db_session, True)
    db_session.flush()
    can_send, reason = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is False
    assert "pausa" in reason


def test_resume_allows_sending_again(db_session):
    queue_service.set_paused(db_session, True)
    db_session.flush()
    queue_service.set_paused(db_session, False)
    db_session.flush()
    can_send, _ = queue_service.can_send_now(db_session, now=MONDAY_10AM)
    assert can_send is True
