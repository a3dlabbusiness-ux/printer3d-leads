from datetime import datetime, timedelta

from app.database.models import WebSession
from app.web import security


def test_check_password_rejects_when_not_configured(monkeypatch):
    monkeypatch.setattr(security.settings, "web_admin_password", "")
    assert security.check_password("qualsiasi") is False


def test_check_password_accepts_correct_password(monkeypatch):
    monkeypatch.setattr(security.settings, "web_admin_password", "supersegreta")
    assert security.check_password("supersegreta") is True
    assert security.check_password("sbagliata") is False


def test_create_and_validate_session(db_session):
    token = security.create_session(db_session)
    db_session.flush()
    assert security.validate_session(db_session, token) is True


def test_validate_session_rejects_unknown_token(db_session):
    assert security.validate_session(db_session, "token-inesistente") is False


def test_validate_session_rejects_expired_token(db_session):
    expired = WebSession(
        token="scaduto123",
        expires_at=datetime.utcnow() - timedelta(hours=1),
    )
    db_session.add(expired)
    db_session.flush()
    assert security.validate_session(db_session, "scaduto123") is False


def test_delete_session_removes_token(db_session):
    token = security.create_session(db_session)
    db_session.flush()
    security.delete_session(db_session, token)
    db_session.flush()
    assert security.validate_session(db_session, token) is False


def test_validate_session_with_none_token(db_session):
    assert security.validate_session(db_session, None) is False
