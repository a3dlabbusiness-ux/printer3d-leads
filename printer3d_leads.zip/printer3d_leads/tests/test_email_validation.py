from app.leads.site_analyzer import _clean_emails, EMAIL_REGEX


def test_email_regex_finds_valid_addresses():
    text = "Scrivici a info@esempio.it oppure a prova.mail+tag@sotto.dominio.com per informazioni."
    found = EMAIL_REGEX.findall(text)
    assert "info@esempio.it" in found
    assert "prova.mail+tag@sotto.dominio.com" in found


def test_email_regex_ignores_non_email_text():
    text = "Questo testo non contiene indirizzi email validi, solo una @ isolata."
    found = EMAIL_REGEX.findall(text)
    assert found == []


def test_clean_emails_filters_ignored_domains():
    raw = ["mario@bar.it", "noreply@sentry.io", "test@example.com"]
    cleaned = _clean_emails(raw)
    assert cleaned == ["mario@bar.it"]


def test_clean_emails_filters_image_extensions():
    raw = ["logo@2x.png", "vera@azienda.it"]
    cleaned = _clean_emails(raw)
    assert cleaned == ["vera@azienda.it"]


def test_clean_emails_strips_trailing_punctuation():
    raw = ["mario@bar.it.,;:"]
    cleaned = _clean_emails(raw)
    assert cleaned == ["mario@bar.it"]
