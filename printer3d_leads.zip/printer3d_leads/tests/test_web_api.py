"""
Test end-to-end della web API con FastAPI TestClient.

Nota: questi test usano lo stesso database di test isolato definito in
conftest.py (variabile DATABASE_URL puntata a un file temporaneo).
"""
import pytest
from fastapi.testclient import TestClient

from app.database.db import SessionLocal
from app.database.models import EmailDraft, Lead, LeadStatus, Source
from app.web.api import app

client = TestClient(app)


@pytest.fixture()
def authenticated_client(db_session):
    resp = client.post("/api/login", json={"password": "test-password-123"})
    assert resp.status_code == 200
    return client


def test_login_wrong_password_rejected(db_session):
    resp = client.post("/api/login", json={"password": "sbagliata"})
    assert resp.status_code == 401


def test_login_correct_password_sets_cookie(db_session):
    resp = client.post("/api/login", json={"password": "test-password-123"})
    assert resp.status_code == 200
    assert "p3d_session" in resp.cookies


def test_pending_leads_requires_auth(db_session):
    fresh_client = TestClient(app)  # senza cookie di sessione
    resp = fresh_client.get("/api/leads/pending")
    assert resp.status_code == 401


def test_pending_leads_lists_only_pending_review(authenticated_client, db_session):
    session = SessionLocal()
    try:
        source = Source(name="csv")
        session.add(source)
        session.flush()
        lead = Lead(
            name="Bar Test API", category="bar", city="Catania",
            email="bar@example.it", status=LeadStatus.PENDING_REVIEW, source=source,
        )
        session.add(lead)
        session.flush()
        session.add(EmailDraft(lead_id=lead.id, subject="Oggetto test", body="Corpo test", is_active=True))
        session.commit()
        lead_id = lead.id
    finally:
        session.close()

    resp = authenticated_client.get("/api/leads/pending")
    assert resp.status_code == 200
    data = resp.json()
    assert any(l["id"] == lead_id and l["name"] == "Bar Test API" for l in data)


def test_approve_lead_moves_to_queue(authenticated_client, db_session):
    session = SessionLocal()
    try:
        source = Source(name="csv")
        session.add(source)
        session.flush()
        lead = Lead(
            name="Bar Da Approvare", category="bar", city="Catania",
            email="approva@example.it", status=LeadStatus.PENDING_REVIEW, source=source,
        )
        session.add(lead)
        session.flush()
        session.add(EmailDraft(lead_id=lead.id, subject="Oggetto", body="Corpo", is_active=True))
        session.commit()
        lead_id = lead.id
    finally:
        session.close()

    resp = authenticated_client.post(f"/api/leads/{lead_id}/approve")
    assert resp.status_code == 200
    assert resp.json()["status"] == "QUEUED"

    queue_resp = authenticated_client.get("/api/queue")
    assert queue_resp.status_code == 200
    assert any(item["to_email"] == "approva@example.it" for item in queue_resp.json())


def test_settings_endpoint_returns_expected_keys(authenticated_client, db_session):
    resp = authenticated_client.get("/api/settings")
    assert resp.status_code == 200
    data = resp.json()
    for key in ("lead_provider", "ai_provider", "max_emails_per_day", "paused"):
        assert key in data
