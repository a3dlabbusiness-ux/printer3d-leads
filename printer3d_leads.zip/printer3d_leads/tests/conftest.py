"""
Configurazione condivisa dei test.

Imposta variabili d'ambiente fittizie PRIMA di importare qualunque modulo
dell'app, così i test non toccano mai il vero database o le vere API.
"""
import os
import sys
import tempfile
from pathlib import Path

# Directory temporanea per il DB di test (un file diverso per ogni sessione di test)
_tmp_dir = tempfile.mkdtemp(prefix="printer3d_leads_test_")
_test_db_path = Path(_tmp_dir) / "test_leads.db"

os.environ["DATABASE_URL"] = f"sqlite:///{_test_db_path}"
os.environ["TELEGRAM_BOT_TOKEN"] = "test-token"
os.environ["TELEGRAM_ADMIN_ID"] = "123456789"
os.environ["AI_PROVIDER"] = "template"
os.environ["LEAD_PROVIDER"] = "csv"
os.environ["SENDER_COMPANY_NAME"] = "Test Company"
os.environ["WEB_ADMIN_PASSWORD"] = "test-password-123"

# Assicura che la root del progetto sia nel path (utile se pytest viene lanciato da altre dir)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pytest  # noqa: E402

from app.database.db import init_db, SessionLocal  # noqa: E402
from app.database.models import Base  # noqa: E402
from app.database.db import engine  # noqa: E402


@pytest.fixture()
def db_session():
    """Fornisce una sessione DB pulita per ogni test (tabelle ricreate da zero)."""
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)
    session = SessionLocal()
    try:
        yield session
        session.commit()
    finally:
        session.close()
