from types import SimpleNamespace

from app.telegram_bot.auth import is_authorized


def _fake_update(user_id):
    user = SimpleNamespace(id=user_id)
    return SimpleNamespace(effective_user=user)


def test_authorized_user_passes():
    # TELEGRAM_ADMIN_ID è impostato a 123456789 in conftest.py
    update = _fake_update(123456789)
    assert is_authorized(update) is True


def test_unauthorized_user_blocked():
    update = _fake_update(999999999)
    assert is_authorized(update) is False


def test_no_user_blocked():
    update = SimpleNamespace(effective_user=None)
    assert is_authorized(update) is False
