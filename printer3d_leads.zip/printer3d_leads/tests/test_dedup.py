from app.database.models import Lead, Source
from app.services import dedup


def _make_lead(session, **kwargs):
    source = Source(name="csv")
    session.add(source)
    session.flush()
    defaults = dict(
        name="Bar Centrale",
        category="bar",
        city="Catania",
        address="Via Roma 1",
        website="https://barcentrale.it",
        domain="barcentrale.it",
        email="info@barcentrale.it",
        phone="+390951234567",
        source=source,
    )
    defaults.update(kwargs)
    lead = Lead(**defaults)
    session.add(lead)
    session.flush()
    return lead


def test_find_existing_lead_by_domain(db_session):
    _make_lead(db_session)
    found = dedup.find_existing_lead(db_session, name="Altro Nome", website="https://www.barcentrale.it")
    assert found is not None
    assert found.domain == "barcentrale.it"


def test_find_existing_lead_by_email(db_session):
    _make_lead(db_session)
    found = dedup.find_existing_lead(db_session, name="Altro Nome", email="INFO@barcentrale.it")
    assert found is not None


def test_find_existing_lead_by_phone(db_session):
    _make_lead(db_session)
    found = dedup.find_existing_lead(db_session, name="Altro Nome", phone="+39 095 123 4567")
    assert found is not None


def test_find_existing_lead_by_name_and_address(db_session):
    _make_lead(db_session)
    found = dedup.find_existing_lead(db_session, name="Bar Centrale", address="Via Roma 1")
    assert found is not None


def test_no_false_positive_for_different_lead(db_session):
    _make_lead(db_session)
    found = dedup.find_existing_lead(
        db_session, name="Pasticceria Diversa", address="Via Etnea 99",
        website="https://altrosito.it", email="altro@altrosito.it", phone="+390957654321",
    )
    assert found is None


def test_normalize_domain_strips_www_and_scheme():
    assert dedup.normalize_domain("https://www.example.com/path") == "example.com"
    assert dedup.normalize_domain("example.com") == "example.com"
    assert dedup.normalize_domain(None) is None


def test_normalize_phone_strips_formatting():
    assert dedup.normalize_phone("+39 095 123 4567") == "+390951234567"
    assert dedup.normalize_phone(None) is None
