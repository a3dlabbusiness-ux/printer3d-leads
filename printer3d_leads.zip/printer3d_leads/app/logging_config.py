"""
Configurazione del sistema di logging.

Regola importante: qui non viene MAI loggata una password o una API key.
I moduli che gestiscono credenziali (email_sender, ai, telegram) devono
loggare solo esiti (successo/errore), mai i valori segreti stessi.
"""
import logging
import logging.handlers
from pathlib import Path

from app.config import settings


def setup_logging() -> None:
    log_path = Path(settings.log_file)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(settings.log_level.upper())

    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    )

    if not root.handlers:
        console = logging.StreamHandler()
        console.setFormatter(fmt)
        root.addHandler(console)

        file_handler = logging.handlers.RotatingFileHandler(
            log_path, maxBytes=5_000_000, backupCount=5, encoding="utf-8"
        )
        file_handler.setFormatter(fmt)
        root.addHandler(file_handler)

    # Riduci il rumore di librerie molto verbose
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("apscheduler").setLevel(logging.WARNING)
