"""
Modulo 8 — Rilevamento risposte via IMAP.

Controlla periodicamente la casella IMAP configurata, cerca email non lette
provenienti da indirizzi che coincidono con lead già contattati, e:
- collega la risposta al lead;
- cambia stato in REPLIED;
- salva il testo della risposta;
- (il chiamante, es. bot.py, invia la notifica Telegram).

NON genera né invia MAI automaticamente una risposta: al massimo prepara
una bozza (tramite AI provider) che resta da approvare manualmente,
esattamente come le email di primo contatto.

Se IMAP non è configurato, il modulo resta semplicemente inattivo: nessun
errore bloccante per il resto del sistema.
"""
from __future__ import annotations

import email
import imaplib
import logging
from dataclasses import dataclass
from email.header import decode_header
from typing import List, Optional

from sqlalchemy.orm import Session

from app.ai.base import LeadContext
from app.ai.factory import get_ai_provider
from app.config import settings
from app.database.models import EmailDraft, EventLog, Lead, LeadStatus

logger = logging.getLogger(__name__)


@dataclass
class IncomingReply:
    from_email: str
    subject: str
    body: str


def imap_configured() -> bool:
    return bool(settings.imap_host and settings.imap_username and settings.imap_password)


def _decode(value: Optional[str]) -> str:
    if not value:
        return ""
    parts = decode_header(value)
    decoded = ""
    for text, enc in parts:
        if isinstance(text, bytes):
            decoded += text.decode(enc or "utf-8", errors="ignore")
        else:
            decoded += text
    return decoded


def fetch_unread_replies(mailbox: str = "INBOX", limit: int = 20) -> List[IncomingReply]:
    """Legge (senza cancellare) le email non lette e le restituisce come oggetti semplici."""
    if not imap_configured():
        return []

    replies: List[IncomingReply] = []
    try:
        conn = imaplib.IMAP4_SSL(settings.imap_host, settings.imap_port)
        conn.login(settings.imap_username, settings.imap_password)
        conn.select(mailbox)

        status, data = conn.search(None, "UNSEEN")
        if status != "OK":
            conn.logout()
            return []

        ids = data[0].split()[-limit:]
        for msg_id in ids:
            status, msg_data = conn.fetch(msg_id, "(RFC822)")
            if status != "OK" or not msg_data or not msg_data[0]:
                continue
            raw_email = msg_data[0][1]
            msg = email.message_from_bytes(raw_email)

            from_header = _decode(msg.get("From", ""))
            from_email = from_header.split("<")[-1].strip(">").strip().lower()

            subject = _decode(msg.get("Subject", ""))

            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain" and not part.get(
                        "Content-Disposition"
                    ):
                        try:
                            body = part.get_payload(decode=True).decode(
                                part.get_content_charset() or "utf-8", errors="ignore"
                            )
                        except Exception:
                            continue
                        break
            else:
                try:
                    body = msg.get_payload(decode=True).decode(
                        msg.get_content_charset() or "utf-8", errors="ignore"
                    )
                except Exception:
                    body = str(msg.get_payload())

            replies.append(IncomingReply(from_email=from_email, subject=subject, body=body.strip()))

        conn.logout()
    except Exception as exc:
        logger.error("Errore durante la lettura IMAP: %s", exc)
        return []

    return replies


def process_replies(session: Session) -> List[Lead]:
    """Collega le risposte trovate ai lead corrispondenti, aggiorna stato e prepara bozza di risposta."""
    updated_leads: List[Lead] = []
    replies = fetch_unread_replies()

    if not replies:
        return updated_leads

    ai_provider = get_ai_provider()

    for reply in replies:
        lead = session.query(Lead).filter(Lead.email == reply.from_email).first()
        if not lead:
            logger.info("Risposta ricevuta da %s ma nessun lead corrispondente trovato.", reply.from_email)
            continue

        lead.status = LeadStatus.REPLIED
        lead.notes = (lead.notes or "") + f"\n[Risposta ricevuta] {reply.subject}: {reply.body[:500]}"

        session.add(
            EventLog(
                event_type="REPLY_RECEIVED",
                message=f"Risposta ricevuta da {reply.from_email}",
                lead_id=lead.id,
            )
        )

        # Prepara SOLO una bozza di risposta, mai inviata automaticamente
        try:
            context = LeadContext(
                name=lead.name,
                category=lead.category,
                city=lead.city,
                site_excerpt=f"Risposta ricevuta dal cliente: {reply.body[:800]}",
                sender_company_name=settings.sender_company_name,
                opt_out_text="",
            )
            draft_result = ai_provider.generate_email_draft(context)
            session.add(
                EmailDraft(
                    lead_id=lead.id,
                    subject=f"RE: {reply.subject}" if reply.subject else "RE: la tua richiesta",
                    body=draft_result.body,
                    ai_generated=draft_result.ai_generated,
                    template_name="reply_draft",
                    is_active=False,  # è solo una bozza suggerita, non sostituisce quella attiva
                )
            )
        except Exception as exc:
            logger.warning("Impossibile generare bozza di risposta per lead %d: %s", lead.id, exc)

        updated_leads.append(lead)

    session.flush()
    return updated_leads
