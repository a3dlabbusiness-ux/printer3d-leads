"""Modulo 12 — Autorizzazione: solo TELEGRAM_ADMIN_ID può usare comandi/bottoni."""
from __future__ import annotations

import logging

from telegram import Update

from app.config import settings

logger = logging.getLogger(__name__)


def is_authorized(update: Update) -> bool:
    user = update.effective_user
    if not user:
        return False
    authorized = user.id == settings.telegram_admin_id
    if not authorized:
        logger.warning("Accesso NON autorizzato al bot da Telegram user_id=%s", user.id)
    return authorized
