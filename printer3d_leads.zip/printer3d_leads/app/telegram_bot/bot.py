"""
Costruzione dell'applicazione python-telegram-bot e registrazione di tutti
i comandi/handler (Moduli 5 e 10).
"""
from __future__ import annotations

import logging

from telegram import Bot
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    MessageHandler,
    filters,
)

from app.config import settings
from app.telegram_bot import handlers

logger = logging.getLogger(__name__)


def build_application() -> Application:
    if not settings.telegram_bot_token:
        raise RuntimeError(
            "TELEGRAM_BOT_TOKEN non configurato. Aggiungilo nel file .env "
            "(vedi README su come crearlo con @BotFather)."
        )
    if not settings.telegram_admin_id:
        raise RuntimeError(
            "TELEGRAM_ADMIN_ID non configurato. Aggiungilo nel file .env "
            "(vedi README su come ottenere il tuo user id)."
        )

    application = Application.builder().token(settings.telegram_bot_token).build()

    application.add_handler(CommandHandler("start", handlers.cmd_start))
    application.add_handler(CommandHandler("help", handlers.cmd_help))
    application.add_handler(CommandHandler("cerca", handlers.cmd_cerca))
    application.add_handler(CommandHandler("stats", handlers.cmd_stats))
    application.add_handler(CommandHandler("queue", handlers.cmd_queue))
    application.add_handler(CommandHandler("today", handlers.cmd_today))
    application.add_handler(CommandHandler("recent", handlers.cmd_recent))
    application.add_handler(CommandHandler("blacklist", handlers.cmd_blacklist))
    application.add_handler(CommandHandler("settings", handlers.cmd_settings))
    application.add_handler(CommandHandler("pause", handlers.cmd_pause))
    application.add_handler(CommandHandler("resume", handlers.cmd_resume))

    application.add_handler(
        CallbackQueryHandler(handlers.on_confirm_edit, pattern=r"^confirm_edit:\d+$")
    )
    application.add_handler(
        CallbackQueryHandler(handlers.on_lead_button, pattern=r"^(approve|skip|blacklist|edit):\d+$")
    )

    # Testo libero: usato solo per catturare la modifica manuale della bozza email
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handlers.on_edit_message))

    return application


async def notify_admin_text(bot: Bot, text: str) -> None:
    """Invia un messaggio testuale semplice all'admin (es. errori, nuove risposte)."""
    if not settings.telegram_admin_id:
        logger.warning("Impossibile notificare: TELEGRAM_ADMIN_ID non configurato.")
        return
    try:
        await bot.send_message(chat_id=settings.telegram_admin_id, text=text, parse_mode="Markdown")
    except Exception as exc:
        logger.error("Errore invio notifica Telegram: %s", exc)
