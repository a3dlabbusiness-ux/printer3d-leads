"""
Modelli del database.

Entità principali:
- Lead: un'attività commerciale potenziale cliente (unisce anche i dati di contatto)
- EmailDraft: bozza email generata per un lead (può avere più versioni)
- EmailMessage: email effettivamente inviata (o tentativo fallito)
- Approval: decisione presa dall'admin su Telegram per un lead
- Blacklist: identificatori bloccati definitivamente
- Source: fonte da cui è stato trovato un lead (provider)
- Campaign: una ricerca lanciata (es. "50 bar a Catania")
- SettingKV: impostazioni runtime modificabili (es. stato pausa invii)
- EventLog: log strutturato degli eventi di sistema
"""
from __future__ import annotations

import enum
from datetime import datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, relationship


class Base(DeclarativeBase):
    pass


class LeadStatus(str, enum.Enum):
    NEW = "NEW"
    PENDING_REVIEW = "PENDING_REVIEW"
    APPROVED = "APPROVED"
    QUEUED = "QUEUED"
    SENT = "SENT"
    SKIPPED = "SKIPPED"
    BLACKLISTED = "BLACKLISTED"
    REPLIED = "REPLIED"
    INTERESTED = "INTERESTED"
    NOT_INTERESTED = "NOT_INTERESTED"
    CLIENT = "CLIENT"
    ERROR = "ERROR"


class ApprovalDecision(str, enum.Enum):
    APPROVE = "APPROVE"
    EDIT = "EDIT"
    SKIP = "SKIP"
    BLACKLIST = "BLACKLIST"


class Campaign(Base):
    __tablename__ = "campaigns"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    city = Column(String(120), nullable=False)
    province = Column(String(10), nullable=True)
    category = Column(String(120), nullable=False)
    keywords = Column(String(255), nullable=True)
    max_results = Column(Integer, default=20)
    created_at = Column(DateTime, default=datetime.utcnow)

    leads = relationship("Lead", back_populates="campaign")


class Source(Base):
    __tablename__ = "sources"

    id = Column(Integer, primary_key=True)
    name = Column(String(120), unique=True, nullable=False)  # es. "google_places", "csv"
    description = Column(String(255), nullable=True)

    leads = relationship("Lead", back_populates="source")


class Lead(Base):
    __tablename__ = "leads"
    __table_args__ = (
        UniqueConstraint("name", "address", name="uq_lead_name_address"),
    )

    id = Column(Integer, primary_key=True)

    name = Column(String(255), nullable=False)
    category = Column(String(120), nullable=True)
    city = Column(String(120), nullable=True)
    province = Column(String(10), nullable=True)
    address = Column(String(255), nullable=True)

    website = Column(String(500), nullable=True)
    domain = Column(String(255), nullable=True, index=True)  # per dedup
    email = Column(String(255), nullable=True, index=True)
    phone = Column(String(50), nullable=True, index=True)
    social_links = Column(Text, nullable=True)  # JSON string

    source_id = Column(Integer, ForeignKey("sources.id"), nullable=True)
    source = relationship("Source", back_populates="leads")

    campaign_id = Column(Integer, ForeignKey("campaigns.id"), nullable=True)
    campaign = relationship("Campaign", back_populates="leads")

    status = Column(Enum(LeadStatus), default=LeadStatus.NEW, nullable=False, index=True)

    # Analisi (basata solo su dati reali raccolti dal sito)
    site_analysis = Column(Text, nullable=True)
    suggested_products = Column(String(500), nullable=True)

    discovered_at = Column(DateTime, default=datetime.utcnow)
    approved_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)

    notes = Column(Text, nullable=True)
    last_error = Column(Text, nullable=True)

    drafts = relationship("EmailDraft", back_populates="lead", cascade="all, delete-orphan")
    messages = relationship("EmailMessage", back_populates="lead", cascade="all, delete-orphan")
    approvals = relationship("Approval", back_populates="lead", cascade="all, delete-orphan")


class EmailDraft(Base):
    __tablename__ = "email_drafts"

    id = Column(Integer, primary_key=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    lead = relationship("Lead", back_populates="drafts")

    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    version = Column(Integer, default=1)
    ai_generated = Column(Boolean, default=False)
    template_name = Column(String(120), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)  # ultima versione valida


class EmailMessage(Base):
    __tablename__ = "email_messages"

    id = Column(Integer, primary_key=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    lead = relationship("Lead", back_populates="messages")

    draft_id = Column(Integer, ForeignKey("email_drafts.id"), nullable=True)

    subject = Column(String(255), nullable=False)
    body = Column(Text, nullable=False)
    to_email = Column(String(255), nullable=False)

    queued_at = Column(DateTime, default=datetime.utcnow)
    sent_at = Column(DateTime, nullable=True)

    status = Column(String(50), default="QUEUED")  # QUEUED, SENT, FAILED, CANCELLED
    error = Column(Text, nullable=True)
    provider_message_id = Column(String(255), nullable=True)


class Approval(Base):
    __tablename__ = "approvals"

    id = Column(Integer, primary_key=True)
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=False)
    lead = relationship("Lead", back_populates="approvals")

    decision = Column(Enum(ApprovalDecision), nullable=False)
    telegram_user_id = Column(Integer, nullable=True)
    note = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Blacklist(Base):
    __tablename__ = "blacklist"

    id = Column(Integer, primary_key=True)
    identifier_type = Column(String(50), nullable=False)  # domain, email, phone, name_address
    identifier_value = Column(String(255), nullable=False, index=True)
    reason = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("identifier_type", "identifier_value", name="uq_blacklist_entry"),
    )


class SettingKV(Base):
    """Impostazioni runtime modificabili senza riavviare (es. pausa invii)."""
    __tablename__ = "settings_kv"

    key = Column(String(100), primary_key=True)
    value = Column(String(500), nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class WebSession(Base):
    """Sessione di login per la web-app (PWA) che sostituisce Telegram come interfaccia."""
    __tablename__ = "web_sessions"

    token = Column(String(128), primary_key=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=False)
    last_seen_at = Column(DateTime, default=datetime.utcnow)


class EventLog(Base):
    __tablename__ = "event_log"

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    level = Column(String(20), default="INFO")
    event_type = Column(String(100), nullable=False)  # es. SEARCH, APPROVE, EMAIL_SENT, ERROR
    lead_id = Column(Integer, ForeignKey("leads.id"), nullable=True)
    message = Column(Text, nullable=True)
    payload = Column(Text, nullable=True)  # JSON string opzionale
