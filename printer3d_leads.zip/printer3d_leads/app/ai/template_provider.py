"""
Provider AI "finto": non chiama nessuna API esterna, genera l'email
componendo dei template testuali. È il default (AI_PROVIDER=template)
e garantisce che il sistema funzioni anche senza alcuna API key AI.
"""
from __future__ import annotations

from app.ai.base import AIProvider, EmailDraftResult, LeadContext

DEFAULT_PRODUCTS = (
    "sottobicchieri, portachiavi, targhette ed espositori personalizzati con logo"
)

CATEGORY_PRODUCT_HINTS = {
    "bar": "sottobicchieri e portapenne personalizzati con il vostro logo",
    "pasticceria": "espositori da banco e cake topper personalizzati",
    "ristorante": "segnaposto, sottobicchieri e porta-menu personalizzati",
    "pizzeria": "porta-menu e segnatavolo personalizzati con logo",
    "hotel": "portachiavi per le camere e targhette personalizzate",
    "b&b": "portachiavi e targhette da camera personalizzate",
    "negozio": "espositori da banco e targhette personalizzate",
    "palestra": "portachiavi e gadget personalizzati per i soci",
    "parrucchiere": "specchietti e portapettini personalizzati",
    "centro estetico": "espositori e gadget personalizzati per la clientela",
    "concessionaria": "portachiavi personalizzati con logo per la consegna auto",
    "agenzia immobiliare": "portachiavi personalizzati per le chiavi degli immobili",
}


class TemplateAIProvider(AIProvider):
    name = "template"

    def generate_email_draft(self, context: LeadContext) -> EmailDraftResult:
        category_key = (context.category or "").strip().lower()
        product_hint = CATEGORY_PRODUCT_HINTS.get(category_key, DEFAULT_PRODUCTS)

        subject = f"Articoli personalizzati in stampa 3D per {context.name}"

        body_lines = [
            "Buongiorno,",
            "",
            f"ho visto la vostra attività ({context.name}) e mi occupo della realizzazione "
            "di articoli personalizzati tramite stampa 3D per attività commerciali.",
            f"Per realtà come la vostra realizziamo ad esempio {product_hint}.",
            "Se può interessarvi posso inviarvi alcuni esempi senza impegno.",
            "",
            "Resto a disposizione per qualsiasi informazione.",
        ]

        if context.sender_company_name:
            body_lines += ["", f"Cordiali saluti,\n{context.sender_company_name}"]

        if context.opt_out_text:
            body_lines += ["", context.opt_out_text]

        return EmailDraftResult(subject=subject, body="\n".join(body_lines), ai_generated=False)

    def analyze_lead(self, context: LeadContext) -> str:
        parts = [f"Attività di categoria '{context.category or 'non specificata'}'"]
        if context.city:
            parts.append(f"situata a {context.city}")
        if context.site_excerpt:
            parts.append("con un sito web pubblico da cui è possibile estrarre informazioni")
        return ", ".join(parts) + ". Potenzialmente interessata a gadget/articoli personalizzati."
