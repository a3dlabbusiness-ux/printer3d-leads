"""Factory per ottenere il provider AI configurato in .env (AI_PROVIDER)."""
from __future__ import annotations

from app.ai.base import AIProvider
from app.config import settings


def get_ai_provider() -> AIProvider:
    provider = (settings.ai_provider or "template").lower()
    if provider == "template":
        from app.ai.template_provider import TemplateAIProvider
        return TemplateAIProvider()
    if provider == "anthropic":
        from app.ai.anthropic_provider import AnthropicAIProvider
        return AnthropicAIProvider()
    raise ValueError(f"AI_PROVIDER sconosciuto: '{provider}'. Usa 'template' o 'anthropic'.")
