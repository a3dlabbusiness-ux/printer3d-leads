"""
Interfaccia comune per i provider AI.

Regola fondamentale: al modello vengono passati SOLO dati realmente
raccolti (nome attività, categoria, città, estratto testo del sito).
Il provider non deve mai inventare fatti sull'azienda: se non ci sono
abbastanza informazioni, deve produrre un'email più generica ma onesta.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional


@dataclass
class LeadContext:
    name: str
    category: Optional[str] = None
    city: Optional[str] = None
    site_excerpt: Optional[str] = None  # SOLO testo realmente estratto dal sito
    sender_company_name: str = ""
    opt_out_text: str = ""


@dataclass
class EmailDraftResult:
    subject: str
    body: str
    ai_generated: bool = True


class AIProvider(ABC):
    name: str = "base"

    @abstractmethod
    def generate_email_draft(self, context: LeadContext) -> EmailDraftResult:
        raise NotImplementedError

    @abstractmethod
    def analyze_lead(self, context: LeadContext) -> str:
        """Restituisce una breve analisi (2-3 frasi) del perché il lead è interessante,
        basata ESCLUSIVAMENTE sui dati forniti in context."""
        raise NotImplementedError

    def summarize_reply(self, reply_text: str) -> str:
        """Riassume una risposta email ricevuta (per la notifica Telegram). Opzionale."""
        return reply_text[:500]
