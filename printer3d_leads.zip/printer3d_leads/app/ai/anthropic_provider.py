"""
Provider AI basato sull'API Anthropic (Claude).

Attivo solo se AI_PROVIDER=anthropic e AI_API_KEY è configurata.
Passa al modello ESCLUSIVAMENTE dati realmente raccolti (context),
con istruzioni esplicite di non inventare nulla sull'azienda.
"""
from __future__ import annotations

import logging

from app.ai.base import AIProvider, EmailDraftResult, LeadContext
from app.ai.template_provider import TemplateAIProvider
from app.config import settings

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """Sei un assistente che scrive brevi email commerciali B2B in italiano
per proporre articoli personalizzati in stampa 3D (sottobicchieri, portachiavi, targhette,
espositori, gadget, insegne, bomboniere) ad attività commerciali locali.

REGOLE FERREE:
- Usa SOLO le informazioni fornite nel messaggio. Non inventare MAI dettagli
  sull'azienda (nessuna collaborazione, recensione o cliente inventati).
- Non dire mai "seguo da tempo la vostra attività" o simili se non è un dato fornito.
- Tono professionale, breve, naturale, non aggressivo, non da spam.
- Restituisci SOLO un oggetto JSON valido con due chiavi: "subject" e "body". Nessun altro testo.
"""


class AnthropicAIProvider(AIProvider):
    name = "anthropic"

    def __init__(self):
        self._fallback = TemplateAIProvider()
        self._client = None
        if settings.ai_api_key:
            try:
                import anthropic
                self._client = anthropic.Anthropic(api_key=settings.ai_api_key)
            except Exception as exc:  # pacchetto non installato o altro errore
                logger.error("Impossibile inizializzare client Anthropic: %s", exc)

    def _build_user_message(self, context: LeadContext, task: str) -> str:
        return (
            f"Compito: {task}\n\n"
            f"Nome attività: {context.name}\n"
            f"Categoria: {context.category or 'non specificata'}\n"
            f"Città: {context.city or 'non specificata'}\n"
            f"Estratto testo dal sito (se disponibile): {context.site_excerpt or 'nessuno'}\n"
            f"Nome mittente/azienda: {context.sender_company_name or 'non specificato'}\n"
        )

    def generate_email_draft(self, context: LeadContext) -> EmailDraftResult:
        if not self._client:
            logger.warning("Provider Anthropic non disponibile: uso fallback template.")
            return self._fallback.generate_email_draft(context)

        import json

        try:
            response = self._client.messages.create(
                model=settings.ai_model,
                max_tokens=600,
                system=SYSTEM_PROMPT,
                messages=[
                    {
                        "role": "user",
                        "content": self._build_user_message(
                            context, "Scrivi la bozza email di primo contatto."
                        ),
                    }
                ],
            )
            text = "".join(
                block.text for block in response.content if getattr(block, "type", "") == "text"
            )
            text = text.strip()
            if text.startswith("```"):
                text = text.strip("`")
                text = text.replace("json\n", "", 1) if text.startswith("json\n") else text

            data = json.loads(text)
            body = data["body"]
            if context.opt_out_text and context.opt_out_text not in body:
                body = f"{body}\n\n{context.opt_out_text}"

            return EmailDraftResult(subject=data["subject"], body=body, ai_generated=True)
        except Exception as exc:
            logger.error("Errore generazione email con Anthropic, uso fallback template: %s", exc)
            return self._fallback.generate_email_draft(context)

    def analyze_lead(self, context: LeadContext) -> str:
        if not self._client:
            return self._fallback.analyze_lead(context)
        try:
            response = self._client.messages.create(
                model=settings.ai_model,
                max_tokens=200,
                system=(
                    "Analizza brevemente (massimo 3 frasi, in italiano) perché questa attività "
                    "potrebbe essere interessata a prodotti personalizzati in stampa 3D, basandoti "
                    "SOLO sui dati forniti. Non inventare nulla. Rispondi con solo il testo dell'analisi."
                ),
                messages=[
                    {"role": "user", "content": self._build_user_message(context, "Analizza il lead.")}
                ],
            )
            text = "".join(
                block.text for block in response.content if getattr(block, "type", "") == "text"
            )
            return text.strip() or self._fallback.analyze_lead(context)
        except Exception as exc:
            logger.error("Errore analisi lead con Anthropic, uso fallback template: %s", exc)
            return self._fallback.analyze_lead(context)
