"""
Provider basato sulla API ufficiale "Places API (New)" di Google.

Questo è un servizio a pagamento oltre la soglia gratuita mensile:
l'utente deve attivarlo consapevolmente inserendo GOOGLE_PLACES_API_KEY.

La API restituisce dati pubblici sulle attività (nome, indirizzo, telefono,
sito web) ma NON fornisce email: l'email va cercata separatamente sul sito
(vedi app/leads/site_analyzer.py), mai inventata.
"""
from __future__ import annotations

import logging
from typing import List, Optional

import httpx

from app.config import settings
from app.leads.providers.base import LeadProvider, RawLead

logger = logging.getLogger(__name__)

SEARCH_URL = "https://places.googleapis.com/v1/places:searchText"

FIELD_MASK = ",".join(
    [
        "places.displayName",
        "places.formattedAddress",
        "places.internationalPhoneNumber",
        "places.websiteUri",
        "places.primaryTypeDisplayName",
    ]
)


class GooglePlacesProvider(LeadProvider):
    name = "google_places"

    def __init__(self, api_key: Optional[str] = None, timeout: float = 15.0):
        self.api_key = api_key or settings.google_places_api_key
        self.timeout = timeout

    def search(
        self,
        city: str,
        category: str,
        province: Optional[str] = None,
        max_results: int = 20,
        keywords: Optional[str] = None,
    ) -> List[RawLead]:
        if not self.api_key:
            raise ValueError(
                "GOOGLE_PLACES_API_KEY non configurata. Imposta LEAD_PROVIDER=csv "
                "oppure aggiungi la API key nel file .env."
            )

        query_parts = [category, "a", city]
        if keywords:
            query_parts.append(keywords)
        text_query = " ".join(query_parts)

        headers = {
            "Content-Type": "application/json",
            "X-Goog-Api-Key": self.api_key,
            "X-Goog-FieldMask": FIELD_MASK,
        }
        body = {
            "textQuery": text_query,
            "maxResultCount": min(max_results, 20),  # limite della API per pagina
            "languageCode": "it",
        }

        results: List[RawLead] = []
        try:
            with httpx.Client(timeout=self.timeout) as client:
                resp = client.post(SEARCH_URL, headers=headers, json=body)
                resp.raise_for_status()
                data = resp.json()
        except httpx.HTTPError as exc:
            logger.error("Errore chiamata Google Places API: %s", exc)
            raise

        for place in data.get("places", [])[:max_results]:
            display_name = (place.get("displayName") or {}).get("text")
            if not display_name:
                continue
            results.append(
                RawLead(
                    name=display_name,
                    category=place.get("primaryTypeDisplayName", {}).get("text") if place.get(
                        "primaryTypeDisplayName") else category,
                    city=city,
                    province=province,
                    address=place.get("formattedAddress"),
                    website=place.get("websiteUri"),
                    phone=place.get("internationalPhoneNumber"),
                    email=None,  # Google Places non fornisce email: mai inventarla qui
                    source_name=self.name,
                )
            )

        logger.info("GooglePlacesProvider: trovati %d risultati per '%s'", len(results), text_query)
        return results
