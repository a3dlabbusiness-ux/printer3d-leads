"""
Provider CSV: importa lead da un file CSV preparato manualmente dall'utente
(es. esportato da un elenco pubblico, da una fiera, da una lista compilata a mano).

Questo provider è utile per iniziare SENZA bisogno di alcuna API key, ed è
il default del progetto (LEAD_PROVIDER=csv).

Formato atteso del CSV (intestazioni, l'ordine non conta):
name,category,city,province,address,website,phone,email,social_links

Colonne mancanti vengono semplicemente ignorate (restano None).
"""
from __future__ import annotations

import csv
import logging
from pathlib import Path
from typing import List, Optional

from app.leads.providers.base import LeadProvider, RawLead

logger = logging.getLogger(__name__)


class CsvProvider(LeadProvider):
    name = "csv"

    def __init__(self, csv_path: Optional[str] = None):
        self.csv_path = csv_path

    def search(
        self,
        city: str,
        category: str,
        province: Optional[str] = None,
        max_results: int = 20,
        keywords: Optional[str] = None,
    ) -> List[RawLead]:
        if not self.csv_path:
            raise ValueError(
                "CsvProvider richiede un percorso file CSV. Usa "
                "discovery.search_from_csv(path, ...) oppure imposta csv_path."
            )

        path = Path(self.csv_path)
        if not path.exists():
            raise FileNotFoundError(f"File CSV non trovato: {path}")

        results: List[RawLead] = []
        with path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                row_city = (row.get("city") or "").strip() or city
                row_category = (row.get("category") or "").strip() or category

                # Filtra opzionalmente per città/categoria se il CSV contiene
                # più righe eterogenee
                if city and row.get("city") and city.lower() not in row["city"].lower():
                    continue
                if category and row.get("category") and category.lower() not in row["category"].lower():
                    continue

                social = row.get("social_links", "")
                social_list = [s.strip() for s in social.split("|") if s.strip()] if social else []

                results.append(
                    RawLead(
                        name=(row.get("name") or "").strip(),
                        category=row_category,
                        city=row_city,
                        province=(row.get("province") or province or "").strip() or None,
                        address=(row.get("address") or "").strip() or None,
                        website=(row.get("website") or "").strip() or None,
                        phone=(row.get("phone") or "").strip() or None,
                        email=(row.get("email") or "").strip() or None,
                        social_links=social_list,
                        source_name=self.name,
                    )
                )
                if len(results) >= max_results:
                    break

        logger.info("CsvProvider: caricati %d lead da %s", len(results), path)
        return [r for r in results if r.name]
