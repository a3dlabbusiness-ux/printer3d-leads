"""
Interfaccia comune per tutti i provider di ricerca lead.

Ogni provider deve restituire SOLO dati realmente trovati.
È VIETATO indovinare o generare email/siti/telefoni: se un dato non è
disponibile, il campo deve restare None.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class RawLead:
    name: str
    category: Optional[str] = None
    city: Optional[str] = None
    province: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None  # quasi mai disponibile direttamente dal provider di ricerca
    social_links: List[str] = field(default_factory=list)
    source_name: str = "unknown"


class LeadProvider(ABC):
    """Interfaccia che ogni sorgente di ricerca lead deve implementare."""

    name: str = "base"

    @abstractmethod
    def search(
        self,
        city: str,
        category: str,
        province: Optional[str] = None,
        max_results: int = 20,
        keywords: Optional[str] = None,
    ) -> List[RawLead]:
        """Cerca attività commerciali e restituisce una lista di RawLead."""
        raise NotImplementedError
