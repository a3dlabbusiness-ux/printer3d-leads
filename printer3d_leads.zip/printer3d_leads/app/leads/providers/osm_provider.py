"""
Provider basato su OpenStreetMap (Overpass API).

Nessuna API key richiesta, nessun account, nessuna carta di credito:
è un servizio pubblico e gratuito mantenuto dalla community OpenStreetMap.

Limiti onesti rispetto a Google Places:
- La copertura dei dati dipende da quanto la community ha mappato quella zona
  (nelle grandi città di solito è buona, in zone molto piccole può essere scarsa).
- Le email non sono quasi mai presenti direttamente nei dati OSM: come per gli
  altri provider, l'email viene cercata successivamente sul sito web (se presente)
  dal modulo site_analyzer, mai inventata.
- Il servizio pubblico ha un rate limit gentile: evitiamo ricerche troppo frequenti.
"""
from __future__ import annotations

import logging
from typing import List, Optional

import httpx

from app.leads.providers.base import LeadProvider, RawLead

logger = logging.getLogger(__name__)

OVERPASS_URL = "https://overpass-api.de/api/interpreter"

# Mappa le categorie in italiano ai tag OpenStreetMap più comuni.
# Se una categoria non è in questa mappa, proviamo una ricerca generica per nome.
CATEGORY_TAG_MAP = {
    "bar": [("amenity", "bar"), ("amenity", "cafe"), ("amenity", "pub")],
    "pasticceria": [("shop", "pastry"), ("shop", "confectionery")],
    "ristorante": [("amenity", "restaurant")],
    "ristoranti": [("amenity", "restaurant")],
    "pizzeria": [("amenity", "fast_food"), ("cuisine", "pizza")],
    "hotel": [("tourism", "hotel")],
    "b&b": [("tourism", "guest_house")],
    "negozio": [("shop", "yes")],
    "palestra": [("leisure", "fitness_centre")],
    "parrucchiere": [("shop", "hairdresser")],
    "centro estetico": [("shop", "beauty")],
    "concessionaria": [("shop", "car")],
    "agenzia immobiliare": [("office", "estate_agent")],
}


class OsmProvider(LeadProvider):
    name = "osm"

    def __init__(self, timeout: float = 30.0):
        self.timeout = timeout

    def _build_query(self, city: str, category: str, max_results: int) -> str:
        category_key = category.strip().lower()
        tags = CATEGORY_TAG_MAP.get(category_key)

        if tags:
            tag_filters = "".join(f'nwr["{k}"="{v}"](area.searchArea);' for k, v in tags)
        else:
            # Fallback: cerca per nome generico nella categoria (meno preciso ma funziona sempre)
            tag_filters = f'nwr["name"~"{category}",i](area.searchArea);'

        # Overpass QL: prima troviamo l'area della città per nome, poi cerchiamo dentro
        query = f"""
        [out:json][timeout:25];
        area["name"="{city}"]["boundary"="administrative"]->.searchArea;
        (
          {tag_filters}
        );
        out center {max_results};
        """
        return query

    def search(
        self,
        city: str,
        category: str,
        province: Optional[str] = None,
        max_results: int = 20,
        keywords: Optional[str] = None,
    ) -> List[RawLead]:
        query = self._build_query(city, category, max_results)

        try:
            with httpx.Client(timeout=self.timeout) as client:
                resp = client.post(OVERPASS_URL, data={"data": query})
                resp.raise_for_status()
                data = resp.json()
        except httpx.HTTPError as exc:
            logger.error("Errore chiamata Overpass API: %s", exc)
            raise

        results: List[RawLead] = []
        for element in data.get("elements", [])[:max_results]:
            tags = element.get("tags", {})
            name = tags.get("name")
            if not name:
                continue

            address_parts = [
                tags.get("addr:street"),
                tags.get("addr:housenumber"),
            ]
            address = " ".join(p for p in address_parts if p) or None

            website = tags.get("website") or tags.get("contact:website")
            phone = tags.get("phone") or tags.get("contact:phone")
            email = tags.get("email") or tags.get("contact:email")  # raro ma a volte presente

            results.append(
                RawLead(
                    name=name,
                    category=category,
                    city=city,
                    province=province,
                    address=address,
                    website=website,
                    phone=phone,
                    email=email,
                    source_name=self.name,
                )
            )

        logger.info("OsmProvider: trovati %d risultati per '%s' a '%s'", len(results), category, city)
        return results
