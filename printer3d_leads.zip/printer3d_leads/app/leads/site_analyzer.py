"""
Analizza il sito web pubblico di un'attività per:
1. estrarre un'eventuale email di contatto REALMENTE presente nella pagina
   (mai generata/ipotizzata a partire dal dominio);
2. raccogliere un breve estratto testuale utile per personalizzare l'email
   e capire quale prodotto 3D potrebbe interessare.

Nessun dato viene inventato: se non si trova nulla, i campi restano vuoti.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import List, Optional
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

EMAIL_REGEX = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")

# Pagine tipiche dove trovare l'email di contatto
CANDIDATE_PATHS = ["", "/contatti", "/contact", "/chi-siamo", "/about"]

USER_AGENT = "Mozilla/5.0 (compatible; Printer3DLeadsBot/1.0; +https://example.com/bot)"

# Domini di piattaforme che a volte generano falsi indirizzi email nei placeholder
IGNORED_EMAIL_DOMAINS = {"sentry.io", "example.com", "wixpress.com", "godaddy.com"}


@dataclass
class SiteAnalysis:
    email: Optional[str] = None
    social_links: List[str] = None
    text_excerpt: str = ""
    title: str = ""
    fetched_ok: bool = False

    def __post_init__(self):
        if self.social_links is None:
            self.social_links = []


def _clean_emails(raw_emails: List[str]) -> List[str]:
    cleaned = []
    for e in raw_emails:
        e = e.strip().strip(".,;:")
        domain = e.split("@")[-1].lower()
        if domain in IGNORED_EMAIL_DOMAINS:
            continue
        if e.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".svg")):
            continue
        cleaned.append(e)
    return cleaned


def analyze_website(url: str, timeout: float = 10.0, max_pages: int = 3) -> SiteAnalysis:
    """Visita alcune pagine del sito e restituisce email reale (se trovata) + estratto testo."""
    analysis = SiteAnalysis()
    if not url:
        return analysis

    parsed = urlparse(url if url.startswith("http") else f"https://{url}")
    base = f"{parsed.scheme}://{parsed.netloc}"

    found_emails: List[str] = []
    social_links: set = set()
    text_chunks: List[str] = []
    title = ""

    headers = {"User-Agent": USER_AGENT}

    with httpx.Client(timeout=timeout, headers=headers, follow_redirects=True) as client:
        for path in CANDIDATE_PATHS[:max_pages]:
            page_url = urljoin(base, path)
            try:
                resp = client.get(page_url)
                if resp.status_code >= 400:
                    continue
                analysis.fetched_ok = True
            except httpx.HTTPError as exc:
                logger.debug("Impossibile raggiungere %s: %s", page_url, exc)
                continue

            soup = BeautifulSoup(resp.text, "lxml")

            if not title and soup.title and soup.title.string:
                title = soup.title.string.strip()

            # mailto: link (fonte più affidabile)
            for a in soup.find_all("a", href=True):
                href = a["href"]
                if href.lower().startswith("mailto:"):
                    addr = href.split("mailto:", 1)[1].split("?")[0]
                    found_emails.append(addr)
                if any(s in href for s in ["instagram.com", "facebook.com", "tiktok.com", "linkedin.com"]):
                    social_links.add(href)

            # email nel testo visibile
            visible_text = soup.get_text(separator=" ", strip=True)
            found_emails.extend(EMAIL_REGEX.findall(visible_text))

            if visible_text:
                text_chunks.append(visible_text[:1500])

            if found_emails:
                break  # trovata email, non serve continuare a scandagliare pagine

    cleaned_emails = _clean_emails(found_emails)

    analysis.email = cleaned_emails[0] if cleaned_emails else None
    analysis.social_links = sorted(social_links)
    analysis.text_excerpt = " ".join(text_chunks)[:2000]
    analysis.title = title

    return analysis
