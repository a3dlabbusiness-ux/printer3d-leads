"""
Orchestratore del Modulo 1 (ricerca) + Modulo 3 (analisi sito).

Espone `run_discovery(...)` che:
1. sceglie il provider configurato (o quello passato esplicitamente);
2. cerca le attività;
3. per ognuna, se c'è un sito, prova a trovare un'email pubblica reale
   e un breve estratto di analisi;
4. restituisce una lista di RawLead "arricchiti" pronti per il dedup service.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from app.config import settings
from app.leads.providers.base import LeadProvider, RawLead
from app.leads.providers.csv_provider import CsvProvider
from app.leads.providers.google_places_provider import GooglePlacesProvider
from app.leads.site_analyzer import analyze_website

logger = logging.getLogger(__name__)


def get_provider(provider_name: Optional[str] = None, csv_path: Optional[str] = None) -> LeadProvider:
    provider_name = (provider_name or settings.lead_provider).lower()
    if provider_name == "google_places":
        return GooglePlacesProvider()
    if provider_name == "osm":
        from app.leads.providers.osm_provider import OsmProvider
        return OsmProvider()
    if provider_name == "csv":
        return CsvProvider(csv_path=csv_path or settings.csv_import_path)
    raise ValueError(
        f"Provider di ricerca lead sconosciuto: '{provider_name}'. "
        "Valori supportati: 'csv', 'osm', 'google_places'."
    )


def run_discovery(
    city: str,
    category: str,
    province: Optional[str] = None,
    max_results: int = 20,
    keywords: Optional[str] = None,
    provider_name: Optional[str] = None,
    csv_path: Optional[str] = None,
    analyze_sites: bool = True,
) -> List[RawLead]:
    provider = get_provider(provider_name, csv_path=csv_path)
    logger.info(
        "Avvio ricerca lead: provider=%s città=%s categoria=%s max=%d",
        provider.name, city, category, max_results,
    )

    raw_leads = provider.search(
        city=city, category=category, province=province,
        max_results=max_results, keywords=keywords,
    )

    if analyze_sites:
        for lead in raw_leads:
            if not lead.website:
                continue
            try:
                analysis = analyze_website(lead.website)
            except Exception as exc:  # non deve mai bloccare l'intera ricerca
                logger.warning("Analisi sito fallita per %s (%s): %s", lead.name, lead.website, exc)
                continue

            if not lead.email and analysis.email:
                lead.email = analysis.email
            if analysis.social_links:
                lead.social_links = sorted(set(lead.social_links) | set(analysis.social_links))
            # Salviamo l'estratto testuale in un attributo dinamico, usato
            # dal servizio di creazione lead per popolare site_analysis
            lead.__dict__["_text_excerpt"] = analysis.text_excerpt

    return raw_leads
