"""
Servizio principale che collega discovery -> dedup -> AI -> database.

Funzione chiave: `ingest_raw_leads(...)` prende i RawLead trovati dal
discovery, per ognuno:
1. verifica se già in blacklist -> scarta;
2. verifica se già presente (dedup) -> scarta (o aggiorna sorgente);
3. crea il Lead nel DB in stato NEW/PENDING_REVIEW;
4. genera l'analisi e la bozza email con il provider AI configurato;
5. registra un EventLog.

Restituisce la lista dei Lead nuovi effettivamente creati e pronti
per essere inviati in revisione su Telegram.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from sqlalchemy.orm import Session

from app.ai.base import LeadContext
from app.ai.factory import get_ai_provider
from app.config import settings
from app.database.models import Campaign, EmailDraft, EventLog, Lead, LeadStatus, Source
from app.leads.providers.base import RawLead
from app.services import dedup

logger = logging.getLogger(__name__)


def _get_or_create_source(session: Session, name: str) -> Source:
    source = session.query(Source).filter(Source.name == name).first()
    if not source:
        source = Source(name=name, description=f"Provider: {name}")
        session.add(source)
        session.flush()
    return source


def _get_or_create_campaign(
    session: Session, city: str, category: str, province: Optional[str], max_results: int
) -> Campaign:
    campaign = Campaign(
        name=f"{category} a {city} ({max_results})",
        city=city,
        province=province,
        category=category,
        max_results=max_results,
    )
    session.add(campaign)
    session.flush()
    return campaign


def _log_event(session: Session, event_type: str, message: str, lead_id: Optional[int] = None):
    session.add(EventLog(event_type=event_type, message=message, lead_id=lead_id))


def ingest_raw_leads(
    session: Session,
    raw_leads: List[RawLead],
    city: str,
    category: str,
    province: Optional[str] = None,
    max_results: int = 20,
    generate_drafts: bool = True,
) -> List[Lead]:
    campaign = _get_or_create_campaign(session, city, category, province, max_results)
    ai_provider = get_ai_provider() if generate_drafts else None

    created_leads: List[Lead] = []

    for raw in raw_leads:
        domain = dedup.normalize_domain(raw.website)

        if dedup.is_blacklisted(
            session, domain=domain, email=raw.email, phone=raw.phone,
            name=raw.name, address=raw.address,
        ):
            logger.info("Lead '%s' ignorato: in blacklist.", raw.name)
            continue

        existing = dedup.find_existing_lead(
            session, name=raw.name, address=raw.address,
            website=raw.website, email=raw.email, phone=raw.phone,
        )
        if existing:
            logger.info("Lead '%s' già presente (id=%d, stato=%s): salto.", raw.name, existing.id, existing.status)
            continue

        source = _get_or_create_source(session, raw.source_name)

        text_excerpt = raw.__dict__.get("_text_excerpt", "")

        lead = Lead(
            name=raw.name,
            category=raw.category or category,
            city=raw.city or city,
            province=raw.province or province,
            address=raw.address,
            website=raw.website,
            domain=domain,
            email=dedup.normalize_email(raw.email),
            phone=dedup.normalize_phone(raw.phone),
            social_links=",".join(raw.social_links) if raw.social_links else None,
            source=source,
            campaign=campaign,
            status=LeadStatus.PENDING_REVIEW if raw.email else LeadStatus.NEW,
            site_analysis=None,
        )
        session.add(lead)
        session.flush()  # per avere lead.id

        context = LeadContext(
            name=lead.name,
            category=lead.category,
            city=lead.city,
            site_excerpt=text_excerpt or None,
            sender_company_name=settings.sender_company_name,
            opt_out_text=settings.opt_out_text,
        )

        if ai_provider:
            try:
                analysis_text = ai_provider.analyze_lead(context)
                lead.site_analysis = analysis_text
            except Exception as exc:
                logger.error("Errore analisi AI per lead %d: %s", lead.id, exc)

            if lead.email:
                try:
                    draft = ai_provider.generate_email_draft(context)
                    session.add(
                        EmailDraft(
                            lead_id=lead.id,
                            subject=draft.subject,
                            body=draft.body,
                            ai_generated=draft.ai_generated,
                            template_name=ai_provider.name,
                        )
                    )
                except Exception as exc:
                    logger.error("Errore generazione bozza email per lead %d: %s", lead.id, exc)

        _log_event(session, "LEAD_DISCOVERED", f"Nuovo lead: {lead.name} ({lead.city})", lead_id=lead.id)
        created_leads.append(lead)

    session.flush()
    logger.info("Ingest completato: %d nuovi lead creati su %d trovati.", len(created_leads), len(raw_leads))
    return created_leads


def get_active_draft(session: Session, lead: Lead) -> Optional[EmailDraft]:
    return (
        session.query(EmailDraft)
        .filter(EmailDraft.lead_id == lead.id, EmailDraft.is_active == True)  # noqa: E712
        .order_by(EmailDraft.version.desc())
        .first()
    )


def update_draft(session: Session, lead: Lead, new_subject: str, new_body: str) -> EmailDraft:
    """Crea una nuova versione della bozza (MODIFICA da Telegram), disattivando le precedenti."""
    old_drafts = session.query(EmailDraft).filter(EmailDraft.lead_id == lead.id).all()
    next_version = (max((d.version for d in old_drafts), default=0)) + 1
    for d in old_drafts:
        d.is_active = False

    new_draft = EmailDraft(
        lead_id=lead.id,
        subject=new_subject,
        body=new_body,
        version=next_version,
        ai_generated=False,
        template_name="manual_edit",
        is_active=True,
    )
    session.add(new_draft)
    _log_event(session, "DRAFT_EDITED", f"Bozza modificata manualmente (v{next_version})", lead_id=lead.id)
    return new_draft
