"""
Modulo 6 — Coda email e limiti di invio.
Modulo 10 — /pause e /resume (stato persistito in SettingKV).
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import List, Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.database.models import EmailDraft, EmailMessage, EventLog, Lead, LeadStatus, SettingKV

logger = logging.getLogger(__name__)

PAUSE_KEY = "sending_paused"


def is_paused(session: Session) -> bool:
    row = session.get(SettingKV, PAUSE_KEY)
    return bool(row and row.value == "true")


def set_paused(session: Session, paused: bool) -> None:
    row = session.get(SettingKV, PAUSE_KEY)
    if not row:
        row = SettingKV(key=PAUSE_KEY, value="false")
        session.add(row)
    row.value = "true" if paused else "false"


def enqueue_approved_lead(session: Session, lead: Lead) -> EmailMessage:
    """Modulo 5 (APPROVA) -> Modulo 6 (coda). Crea un EmailMessage in stato QUEUED."""
    if not lead.email:
        raise ValueError(f"Il lead '{lead.name}' non ha un'email: impossibile mettere in coda.")

    active_draft: Optional[EmailDraft] = (
        session.query(EmailDraft)
        .filter(EmailDraft.lead_id == lead.id, EmailDraft.is_active == True)  # noqa: E712
        .order_by(EmailDraft.version.desc())
        .first()
    )
    if not active_draft:
        raise ValueError(f"Nessuna bozza email trovata per il lead '{lead.name}'.")

    message = EmailMessage(
        lead_id=lead.id,
        draft_id=active_draft.id,
        subject=active_draft.subject,
        body=active_draft.body,
        to_email=lead.email,
        status="QUEUED",
    )
    session.add(message)

    lead.status = LeadStatus.QUEUED
    lead.approved_at = lead.approved_at or datetime.utcnow()

    session.add(EventLog(event_type="LEAD_QUEUED", message=f"Lead {lead.name} messo in coda", lead_id=lead.id))
    session.flush()
    return message


def _within_sending_window(now: datetime) -> bool:
    if now.weekday() not in settings.sending_days_list:
        return False
    return settings.sending_hour_start <= now.hour < settings.sending_hour_end


def _count_sent_since(session: Session, since: datetime) -> int:
    return (
        session.query(EmailMessage)
        .filter(EmailMessage.status == "SENT", EmailMessage.sent_at >= since)
        .count()
    )


def _last_sent_at(session: Session) -> Optional[datetime]:
    last = (
        session.query(EmailMessage)
        .filter(EmailMessage.status == "SENT")
        .order_by(EmailMessage.sent_at.desc())
        .first()
    )
    return last.sent_at if last else None


def can_send_now(session: Session, now: Optional[datetime] = None) -> tuple[bool, str]:
    """Verifica tutti i limiti configurati. Restituisce (puoi_inviare, motivo_se_no)."""
    now = now or datetime.utcnow()

    if is_paused(session):
        return False, "invii in pausa (/resume per riattivare)"

    if not _within_sending_window(now):
        return False, "fuori dalla fascia oraria/giorni di invio consentiti"

    sent_today = _count_sent_since(session, now.replace(hour=0, minute=0, second=0, microsecond=0))
    if sent_today >= settings.max_emails_per_day:
        return False, f"raggiunto il limite giornaliero ({settings.max_emails_per_day})"

    sent_last_hour = _count_sent_since(session, now - timedelta(hours=1))
    if sent_last_hour >= settings.max_emails_per_hour:
        return False, f"raggiunto il limite orario ({settings.max_emails_per_hour})"

    last_sent = _last_sent_at(session)
    if last_sent:
        elapsed = (now - last_sent).total_seconds()
        if elapsed < settings.min_seconds_between_emails:
            return False, "troppo poco tempo dall'ultimo invio"

    return True, ""


def get_next_queued_message(session: Session) -> Optional[EmailMessage]:
    return (
        session.query(EmailMessage)
        .filter(EmailMessage.status == "QUEUED")
        .order_by(EmailMessage.queued_at.asc())
        .first()
    )


def list_queue(session: Session) -> List[EmailMessage]:
    return (
        session.query(EmailMessage)
        .filter(EmailMessage.status == "QUEUED")
        .order_by(EmailMessage.queued_at.asc())
        .all()
    )
