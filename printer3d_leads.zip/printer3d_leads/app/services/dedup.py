"""
Modulo 2 — Controllo duplicati e blacklist.

Un lead è considerato duplicato se coincide, con un lead già presente
nel database, per almeno uno di questi identificatori:
- dominio del sito web
- email
- combinazione nome attività + indirizzo
- telefono

Un lead è bloccato se uno qualsiasi dei suoi identificatori compare
nella tabella blacklist.
"""
from __future__ import annotations

import re
from typing import Optional
from urllib.parse import urlparse

from sqlalchemy import or_
from sqlalchemy.orm import Session

from app.database.models import Blacklist, Lead

_PHONE_CLEAN_RE = re.compile(r"[^\d+]")


def normalize_domain(website: Optional[str]) -> Optional[str]:
    if not website:
        return None
    website = website.strip()
    if not website:
        return None
    if not website.startswith("http"):
        website = f"https://{website}"
    netloc = urlparse(website).netloc.lower()
    return netloc[4:] if netloc.startswith("www.") else netloc


def normalize_email(email: Optional[str]) -> Optional[str]:
    return email.strip().lower() if email else None


def normalize_phone(phone: Optional[str]) -> Optional[str]:
    if not phone:
        return None
    cleaned = _PHONE_CLEAN_RE.sub("", phone)
    return cleaned or None


def normalize_name_address(name: Optional[str], address: Optional[str]) -> Optional[str]:
    if not name:
        return None
    key = f"{name.strip().lower()}|{(address or '').strip().lower()}"
    return key


def find_existing_lead(
    session: Session,
    name: str,
    address: Optional[str] = None,
    website: Optional[str] = None,
    email: Optional[str] = None,
    phone: Optional[str] = None,
) -> Optional[Lead]:
    """Restituisce un Lead già esistente che corrisponde a uno degli identificatori, se presente."""
    domain = normalize_domain(website)
    norm_email = normalize_email(email)
    norm_phone = normalize_phone(phone)

    filters = []
    if domain:
        filters.append(Lead.domain == domain)
    if norm_email:
        filters.append(Lead.email == norm_email)
    if norm_phone:
        filters.append(Lead.phone == norm_phone)
    filters.append((Lead.name == name) & (Lead.address == address))

    if not filters:
        return None

    return session.query(Lead).filter(or_(*filters)).first()


def is_blacklisted(
    session: Session,
    domain: Optional[str] = None,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    name: Optional[str] = None,
    address: Optional[str] = None,
) -> bool:
    values = []
    if domain:
        values.append(("domain", domain))
    if email:
        values.append(("email", normalize_email(email)))
    if phone:
        values.append(("phone", normalize_phone(phone)))
    name_addr = normalize_name_address(name, address)
    if name_addr:
        values.append(("name_address", name_addr))

    for id_type, id_value in values:
        if not id_value:
            continue
        hit = (
            session.query(Blacklist)
            .filter(Blacklist.identifier_type == id_type, Blacklist.identifier_value == id_value)
            .first()
        )
        if hit:
            return True
    return False


def add_to_blacklist(
    session: Session,
    reason: Optional[str] = None,
    domain: Optional[str] = None,
    email: Optional[str] = None,
    phone: Optional[str] = None,
    name: Optional[str] = None,
    address: Optional[str] = None,
) -> None:
    entries = []
    if domain:
        entries.append(("domain", domain))
    if email:
        entries.append(("email", normalize_email(email)))
    if phone:
        entries.append(("phone", normalize_phone(phone)))
    name_addr = normalize_name_address(name, address)
    if name_addr:
        entries.append(("name_address", name_addr))

    for id_type, id_value in entries:
        if not id_value:
            continue
        exists = (
            session.query(Blacklist)
            .filter(Blacklist.identifier_type == id_type, Blacklist.identifier_value == id_value)
            .first()
        )
        if not exists:
            session.add(Blacklist(identifier_type=id_type, identifier_value=id_value, reason=reason))
