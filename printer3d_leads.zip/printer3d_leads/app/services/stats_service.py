"""Modulo 9 — Statistiche."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database.models import EmailMessage, Lead, LeadStatus


@dataclass
class GlobalStats:
    leads_found: int = 0
    leads_approved: int = 0
    emails_sent: int = 0
    emails_failed: int = 0
    replies: int = 0
    interested: int = 0
    clients: int = 0

    @property
    def approval_rate(self) -> float:
        return round(100 * self.leads_approved / self.leads_found, 1) if self.leads_found else 0.0

    @property
    def reply_rate(self) -> float:
        return round(100 * self.replies / self.emails_sent, 1) if self.emails_sent else 0.0

    @property
    def conversion_rate(self) -> float:
        return round(100 * self.clients / self.emails_sent, 1) if self.emails_sent else 0.0


@dataclass
class CategoryStats:
    category: str
    contacted: int = 0
    replies: int = 0
    clients: int = 0


def get_global_stats(session: Session) -> GlobalStats:
    leads_found = session.query(func.count(Lead.id)).scalar() or 0
    leads_approved = (
        session.query(func.count(Lead.id))
        .filter(Lead.status.in_([
            LeadStatus.APPROVED, LeadStatus.QUEUED, LeadStatus.SENT,
            LeadStatus.REPLIED, LeadStatus.INTERESTED, LeadStatus.NOT_INTERESTED, LeadStatus.CLIENT,
        ]))
        .scalar() or 0
    )
    emails_sent = session.query(func.count(EmailMessage.id)).filter(EmailMessage.status == "SENT").scalar() or 0
    emails_failed = session.query(func.count(EmailMessage.id)).filter(EmailMessage.status == "FAILED").scalar() or 0
    replies = session.query(func.count(Lead.id)).filter(
        Lead.status.in_([LeadStatus.REPLIED, LeadStatus.INTERESTED, LeadStatus.NOT_INTERESTED, LeadStatus.CLIENT])
    ).scalar() or 0
    interested = session.query(func.count(Lead.id)).filter(Lead.status == LeadStatus.INTERESTED).scalar() or 0
    clients = session.query(func.count(Lead.id)).filter(Lead.status == LeadStatus.CLIENT).scalar() or 0

    return GlobalStats(
        leads_found=leads_found,
        leads_approved=leads_approved,
        emails_sent=emails_sent,
        emails_failed=emails_failed,
        replies=replies,
        interested=interested,
        clients=clients,
    )


def get_stats_by_category(session: Session) -> Dict[str, CategoryStats]:
    result: Dict[str, CategoryStats] = {}
    leads = session.query(Lead).filter(Lead.status != LeadStatus.NEW).all()
    for lead in leads:
        cat = lead.category or "Non specificata"
        if cat not in result:
            result[cat] = CategoryStats(category=cat)
        if lead.status in (
            LeadStatus.SENT, LeadStatus.REPLIED, LeadStatus.INTERESTED,
            LeadStatus.NOT_INTERESTED, LeadStatus.CLIENT,
        ):
            result[cat].contacted += 1
        if lead.status in (LeadStatus.REPLIED, LeadStatus.INTERESTED, LeadStatus.NOT_INTERESTED, LeadStatus.CLIENT):
            result[cat].replies += 1
        if lead.status == LeadStatus.CLIENT:
            result[cat].clients += 1
    return result


def get_stats_by_city(session: Session) -> Dict[str, int]:
    rows = (
        session.query(Lead.city, func.count(Lead.id))
        .filter(Lead.status != LeadStatus.NEW)
        .group_by(Lead.city)
        .all()
    )
    return {city or "N/D": count for city, count in rows}
