"""
API web che sostituisce il bot Telegram come interfaccia di controllo.

Espone endpoint REST usati dalla PWA (app/web/static/) per:
- login/logout
- vedere e decidere sui lead in attesa di revisione (approva/modifica/salta/blacklist)
- vedere coda, statistiche, blacklist, lead recenti
- avviare una nuova ricerca
- mettere in pausa/riattivare gli invii

Tutta la logica di business (dedup, stato lead, limiti email, ecc.) resta
nei moduli app/services/*: questo file fa solo da "ponte" verso il frontend.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from fastapi import Cookie, Depends, FastAPI, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from starlette.concurrency import run_in_threadpool

from app.database.db import get_session, init_db
from app.database.models import Approval, ApprovalDecision, Blacklist, EmailMessage, Lead, LeadStatus
from app.services import dedup, lead_service, queue_service, stats_service
from app.web.security import (
    SESSION_COOKIE_NAME,
    check_password,
    create_session,
    delete_session,
    validate_session,
)

logger = logging.getLogger(__name__)

app = FastAPI(title="Printer3D Leads")


# ---------------------------------------------------------------------------
# Modelli richiesta
# ---------------------------------------------------------------------------

class LoginRequest(BaseModel):
    password: str


class DraftUpdateRequest(BaseModel):
    subject: str
    body: str


class SearchRequest(BaseModel):
    city: str
    category: str
    max_results: int = 20
    keywords: Optional[str] = None
    csv_path: Optional[str] = None


class PauseRequest(BaseModel):
    paused: bool


# ---------------------------------------------------------------------------
# Autenticazione
# ---------------------------------------------------------------------------

def require_auth(p3d_session: Optional[str] = Cookie(default=None)) -> str:
    with get_session() as session:
        if not validate_session(session, p3d_session):
            raise HTTPException(status_code=401, detail="Sessione non valida. Effettua di nuovo il login.")
    return p3d_session


@app.post("/api/login")
def login(payload: LoginRequest, response: Response):
    if not check_password(payload.password):
        raise HTTPException(status_code=401, detail="Password errata.")
    with get_session() as session:
        token = create_session(session)
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=token,
        httponly=True,
        samesite="lax",
        max_age=60 * 60 * 24 * 30,
        path="/",
    )
    return {"ok": True}


@app.post("/api/logout")
def logout(response: Response, p3d_session: Optional[str] = Cookie(default=None)):
    with get_session() as session:
        delete_session(session, p3d_session)
    response.delete_cookie(SESSION_COOKIE_NAME, path="/")
    return {"ok": True}


@app.get("/api/session")
def session_status(p3d_session: Optional[str] = Cookie(default=None)):
    with get_session() as session:
        return {"authenticated": validate_session(session, p3d_session)}


# ---------------------------------------------------------------------------
# Lead in attesa di revisione
# ---------------------------------------------------------------------------

def _lead_to_dict(lead: Lead, session) -> dict:
    draft = lead_service.get_active_draft(session, lead)
    return {
        "id": lead.id,
        "name": lead.name,
        "category": lead.category,
        "city": lead.city,
        "province": lead.province,
        "address": lead.address,
        "website": lead.website,
        "email": lead.email,
        "phone": lead.phone,
        "source": lead.source.name if lead.source else None,
        "status": lead.status.value,
        "site_analysis": lead.site_analysis,
        "discovered_at": lead.discovered_at.isoformat() if lead.discovered_at else None,
        "draft": {"subject": draft.subject, "body": draft.body} if draft else None,
    }


@app.get("/api/leads/pending")
def list_pending_leads(_: str = Depends(require_auth)):
    with get_session() as session:
        leads = (
            session.query(Lead)
            .filter(Lead.status == LeadStatus.PENDING_REVIEW)
            .order_by(Lead.discovered_at.asc())
            .all()
        )
        return [_lead_to_dict(l, session) for l in leads]


@app.post("/api/leads/{lead_id}/approve")
def approve_lead(lead_id: int, _: str = Depends(require_auth)):
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead non trovato.")
        session.add(Approval(lead_id=lead.id, decision=ApprovalDecision.APPROVE))
        lead.status = LeadStatus.APPROVED
        try:
            queue_service.enqueue_approved_lead(session, lead)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        session.flush()
        return {"ok": True, "status": lead.status.value}


@app.post("/api/leads/{lead_id}/skip")
def skip_lead(lead_id: int, _: str = Depends(require_auth)):
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead non trovato.")
        session.add(Approval(lead_id=lead.id, decision=ApprovalDecision.SKIP))
        lead.status = LeadStatus.SKIPPED
        session.flush()
        return {"ok": True, "status": lead.status.value}


@app.post("/api/leads/{lead_id}/blacklist")
def blacklist_lead(lead_id: int, _: str = Depends(require_auth)):
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead non trovato.")
        session.add(Approval(lead_id=lead.id, decision=ApprovalDecision.BLACKLIST))
        lead.status = LeadStatus.BLACKLISTED
        dedup.add_to_blacklist(
            session,
            reason="Bloccato manualmente dalla web-app",
            domain=lead.domain,
            email=lead.email,
            phone=lead.phone,
            name=lead.name,
            address=lead.address,
        )
        session.flush()
        return {"ok": True, "status": lead.status.value}


@app.put("/api/leads/{lead_id}/draft")
def update_lead_draft(lead_id: int, payload: DraftUpdateRequest, _: str = Depends(require_auth)):
    if not payload.subject.strip() or not payload.body.strip():
        raise HTTPException(status_code=400, detail="Oggetto e corpo email non possono essere vuoti.")
    with get_session() as session:
        lead = session.get(Lead, lead_id)
        if not lead:
            raise HTTPException(status_code=404, detail="Lead non trovato.")
        draft = lead_service.update_draft(session, lead, payload.subject, payload.body)
        session.flush()
        return {"ok": True, "draft": {"subject": draft.subject, "body": draft.body}}


# ---------------------------------------------------------------------------
# Ricerca
# ---------------------------------------------------------------------------

@app.post("/api/search")
async def run_search(payload: SearchRequest, _: str = Depends(require_auth)):
    from app.leads.discovery import run_discovery

    def _do_search():
        raw_leads = run_discovery(
            city=payload.city,
            category=payload.category,
            max_results=payload.max_results,
            keywords=payload.keywords,
            csv_path=payload.csv_path,
        )
        with get_session() as session:
            new_leads = lead_service.ingest_raw_leads(
                session, raw_leads, city=payload.city, category=payload.category,
                max_results=payload.max_results,
            )
            session.flush()
            return [_lead_to_dict(l, session) for l in new_leads]

    try:
        new_leads = await run_in_threadpool(_do_search)
    except Exception as exc:
        logger.exception("Errore durante la ricerca lead")
        raise HTTPException(status_code=500, detail=str(exc))

    return {"ok": True, "new_leads_count": len(new_leads), "leads": new_leads}


# ---------------------------------------------------------------------------
# Coda, storico, blacklist, statistiche, impostazioni
# ---------------------------------------------------------------------------

@app.get("/api/queue")
def get_queue(_: str = Depends(require_auth)):
    with get_session() as session:
        messages = queue_service.list_queue(session)
        return [
            {
                "id": m.id,
                "to_email": m.to_email,
                "subject": m.subject,
                "lead_name": m.lead.name if m.lead else None,
                "queued_at": m.queued_at.isoformat() if m.queued_at else None,
            }
            for m in messages
        ]


@app.get("/api/recent")
def get_recent(_: str = Depends(require_auth)):
    with get_session() as session:
        leads = session.query(Lead).order_by(Lead.discovered_at.desc()).limit(30).all()
        return [_lead_to_dict(l, session) for l in leads]


@app.get("/api/blacklist")
def get_blacklist(_: str = Depends(require_auth)):
    with get_session() as session:
        rows = session.query(Blacklist).order_by(Blacklist.created_at.desc()).limit(100).all()
        return [
            {
                "id": b.id,
                "type": b.identifier_type,
                "value": b.identifier_value,
                "reason": b.reason,
                "created_at": b.created_at.isoformat() if b.created_at else None,
            }
            for b in rows
        ]


@app.get("/api/stats")
def get_stats(_: str = Depends(require_auth)):
    with get_session() as session:
        g = stats_service.get_global_stats(session)
        by_cat = stats_service.get_stats_by_category(session)
        by_city = stats_service.get_stats_by_city(session)
        return {
            "global": {
                "leads_found": g.leads_found,
                "leads_approved": g.leads_approved,
                "emails_sent": g.emails_sent,
                "emails_failed": g.emails_failed,
                "replies": g.replies,
                "interested": g.interested,
                "clients": g.clients,
                "approval_rate": g.approval_rate,
                "reply_rate": g.reply_rate,
                "conversion_rate": g.conversion_rate,
            },
            "by_category": {
                cat: {"contacted": cs.contacted, "replies": cs.replies, "clients": cs.clients}
                for cat, cs in by_cat.items()
            },
            "by_city": by_city,
        }


@app.get("/api/settings")
def get_settings(_: str = Depends(require_auth)):
    from app.config import settings as app_settings

    with get_session() as session:
        paused = queue_service.is_paused(session)
    return {
        "lead_provider": app_settings.lead_provider,
        "ai_provider": app_settings.ai_provider,
        "default_city": app_settings.default_city,
        "default_province": app_settings.default_province,
        "max_emails_per_day": app_settings.max_emails_per_day,
        "max_emails_per_hour": app_settings.max_emails_per_hour,
        "min_seconds_between_emails": app_settings.min_seconds_between_emails,
        "sending_hour_start": app_settings.sending_hour_start,
        "sending_hour_end": app_settings.sending_hour_end,
        "paused": paused,
    }


@app.post("/api/settings/pause")
def set_pause(payload: PauseRequest, _: str = Depends(require_auth)):
    with get_session() as session:
        queue_service.set_paused(session, payload.paused)
    return {"ok": True, "paused": payload.paused}


# ---------------------------------------------------------------------------
# Avvio: crea le tabelle e serve i file statici della PWA
# ---------------------------------------------------------------------------

init_db()

_STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/", StaticFiles(directory=str(_STATIC_DIR), html=True), name="static")
