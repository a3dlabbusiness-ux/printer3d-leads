"""
Autenticazione della web-app (PWA).

Sostituisce il controllo "solo il mio Telegram User ID" con: "solo chi conosce
la password impostata in WEB_ADMIN_PASSWORD può entrare". Dopo il login viene
creato un token di sessione salvato nel database e restituito come cookie
HttpOnly, così il telefono resta "loggato" per WEB_SESSION_HOURS senza dover
reinserire la password ogni volta.

Nota di sicurezza: questa app è pensata per uso PERSONALE su rete fidata
(la tua rete di casa, o una rete privata tipo Tailscale). Non esporla
direttamente su internet senza aggiungere HTTPS davanti (es. tramite Tailscale
o un reverse proxy con certificato).
"""
from __future__ import annotations

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta
from typing import Optional

from sqlalchemy.orm import Session

from app.config import settings
from app.database.models import WebSession

SESSION_COOKIE_NAME = "p3d_session"


def _constant_time_check(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode("utf-8"), b.encode("utf-8"))


def check_password(password: str) -> bool:
    if not settings.web_admin_password:
        # Se non è stata impostata nessuna password, per sicurezza NEGA sempre
        # l'accesso, invece di lasciare la app aperta a chiunque.
        return False
    return _constant_time_check(password, settings.web_admin_password)


def create_session(session: Session) -> str:
    token = secrets.token_hex(32)
    expires_at = datetime.utcnow() + timedelta(hours=settings.web_session_hours)
    session.add(WebSession(token=token, expires_at=expires_at))
    session.flush()
    return token


def validate_session(session: Session, token: Optional[str]) -> bool:
    if not token:
        return False
    row = session.get(WebSession, token)
    if not row:
        return False
    if row.expires_at < datetime.utcnow():
        session.delete(row)
        session.flush()
        return False
    row.last_seen_at = datetime.utcnow()
    return True


def delete_session(session: Session, token: Optional[str]) -> None:
    if not token:
        return
    row = session.get(WebSession, token)
    if row:
        session.delete(row)
        session.flush()


def _hash_for_log(token: str) -> str:
    """Non logghiamo mai il token in chiaro nei log, solo un hash breve per debug."""
    return hashlib.sha256(token.encode("utf-8")).hexdigest()[:8]
