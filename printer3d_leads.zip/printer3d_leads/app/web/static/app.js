// Stampa3D Leads — logica della PWA (nessuna libreria esterna, solo fetch + DOM)

const viewLogin = document.getElementById("view-login");
const viewApp = document.getElementById("view-app");

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    credentials: "same-origin",
  });
  if (res.status === 401) {
    showLogin();
    throw new Error("Sessione scaduta");
  }
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data.detail || `Errore ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

function showLogin() {
  viewLogin.hidden = false;
  viewApp.hidden = true;
}

function showApp() {
  viewLogin.hidden = true;
  viewApp.hidden = false;
  loadTab(currentTab);
}

// ---------------------------------------------------------------------------
// Login
// ---------------------------------------------------------------------------

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");
  errorEl.hidden = true;
  try {
    await api("/api/login", { method: "POST", body: JSON.stringify({ password }) });
    showApp();
  } catch (err) {
    errorEl.textContent = "Password errata. Riprova.";
    errorEl.hidden = false;
  }
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  await api("/api/logout", { method: "POST" }).catch(() => {});
  showLogin();
});

async function checkSession() {
  try {
    const data = await api("/api/session");
    if (data.authenticated) {
      showApp();
    } else {
      showLogin();
    }
  } catch {
    showLogin();
  }
}

// ---------------------------------------------------------------------------
// Tab navigation
// ---------------------------------------------------------------------------

let currentTab = "pending";
const tabTitles = {
  pending: "In attesa",
  search: "Cerca lead",
  queue: "Coda email",
  stats: "Statistiche",
  settings: "Impostazioni",
};

document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    document.querySelectorAll(".tab").forEach((t) => (t.hidden = true));
    currentTab = btn.dataset.tab;
    document.getElementById(`tab-${currentTab}`).hidden = false;
    document.getElementById("page-title").textContent = tabTitles[currentTab];
    loadTab(currentTab);
  });
});

function loadTab(tab) {
  if (tab === "pending") loadPending();
  if (tab === "queue") loadQueue();
  if (tab === "stats") loadStats();
  if (tab === "settings") loadSettings();
}

// ---------------------------------------------------------------------------
// Tab: In attesa (revisione lead)
// ---------------------------------------------------------------------------

const leadTemplate = document.getElementById("lead-card-template");

function renderLeadCard(lead) {
  const node = leadTemplate.content.cloneNode(true);
  const card = node.querySelector(".lead-card");
  card.dataset.leadId = lead.id;

  card.querySelector(".lead-name").textContent = lead.name;
  card.querySelector(".lead-category").textContent = lead.category || "-";
  card.querySelector(".lead-city").textContent = lead.city || "-";
  card.querySelector(".lead-email").textContent = lead.email || "non trovata";
  card.querySelector(".lead-phone").textContent = lead.phone || "-";
  card.querySelector(".lead-source").textContent = lead.source || "-";
  card.querySelector(".lead-analysis").textContent = lead.site_analysis || "Analisi non disponibile.";

  const siteLink = card.querySelector(".lead-site-link");
  if (lead.website) {
    siteLink.href = lead.website;
  } else {
    siteLink.remove();
  }

  const subjectInput = card.querySelector(".draft-subject");
  const bodyInput = card.querySelector(".draft-body");
  if (lead.draft) {
    subjectInput.value = lead.draft.subject;
    bodyInput.value = lead.draft.body;
  } else {
    card.querySelector(".draft-box").style.display = "none";
    card.querySelector(".action-approve").disabled = true;
    card.querySelector(".action-approve").title = "Nessuna email trovata per questo lead";
  }

  card.querySelector(".action-approve").addEventListener("click", () => handleApprove(lead.id, card));
  card.querySelector(".action-skip").addEventListener("click", () => handleSkip(lead.id, card));
  card.querySelector(".action-blacklist").addEventListener("click", () => handleBlacklist(lead.id, card));
  card.querySelector(".action-save-edit").addEventListener("click", () =>
    handleSaveEdit(lead.id, subjectInput.value, bodyInput.value)
  );

  return node;
}

async function loadPending() {
  const list = document.getElementById("pending-list");
  const empty = document.getElementById("pending-empty");
  try {
    const leads = await api("/api/leads/pending");
    list.innerHTML = "";
    empty.hidden = leads.length > 0;
    leads.forEach((lead) => list.appendChild(renderLeadCard(lead)));
  } catch (err) {
    console.error(err);
  }
}

async function handleApprove(leadId, card) {
  try {
    await api(`/api/leads/${leadId}/approve`, { method: "POST" });
    card.remove();
    refreshEmptyState();
  } catch (err) {
    alert("Errore durante l'approvazione: " + err.message);
  }
}

async function handleSkip(leadId, card) {
  try {
    await api(`/api/leads/${leadId}/skip`, { method: "POST" });
    card.remove();
    refreshEmptyState();
  } catch (err) {
    alert("Errore: " + err.message);
  }
}

async function handleBlacklist(leadId, card) {
  if (!confirm("Bloccare definitivamente questa attività? Non verrà più riproposta.")) return;
  try {
    await api(`/api/leads/${leadId}/blacklist`, { method: "POST" });
    card.remove();
    refreshEmptyState();
  } catch (err) {
    alert("Errore: " + err.message);
  }
}

async function handleSaveEdit(leadId, subject, body) {
  try {
    await api(`/api/leads/${leadId}/draft`, {
      method: "PUT",
      body: JSON.stringify({ subject, body }),
    });
    alert("Bozza aggiornata. Premi 'Approva' per metterla in coda di invio.");
  } catch (err) {
    alert("Errore: " + err.message);
  }
}

function refreshEmptyState() {
  const list = document.getElementById("pending-list");
  document.getElementById("pending-empty").hidden = list.children.length > 0;
}

// ---------------------------------------------------------------------------
// Tab: Cerca
// ---------------------------------------------------------------------------

document.getElementById("search-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = document.getElementById("search-status");
  const city = document.getElementById("search-city").value.trim();
  const category = document.getElementById("search-category").value.trim();
  const max_results = parseInt(document.getElementById("search-max").value, 10) || 20;
  const keywords = document.getElementById("search-keywords").value.trim();

  status.textContent = "Ricerca in corso, potrebbe metterci qualche minuto...";
  try {
    const result = await api("/api/search", {
      method: "POST",
      body: JSON.stringify({ city, category, max_results, keywords: keywords || null }),
    });
    status.textContent = `Trovati ${result.new_leads_count} nuovi lead. Vai su "In attesa" per rivederli.`;
  } catch (err) {
    status.textContent = "Errore durante la ricerca: " + err.message;
  }
});

// ---------------------------------------------------------------------------
// Tab: Coda
// ---------------------------------------------------------------------------

async function loadQueue() {
  const list = document.getElementById("queue-list");
  const empty = document.getElementById("queue-empty");
  try {
    const items = await api("/api/queue");
    list.innerHTML = "";
    empty.hidden = items.length > 0;
    items.forEach((item) => {
      const div = document.createElement("div");
      div.className = "queue-item";
      div.innerHTML = `<strong>${item.lead_name || "?"}</strong>${item.to_email} — ${item.subject}`;
      list.appendChild(div);
    });
  } catch (err) {
    console.error(err);
  }
}

// ---------------------------------------------------------------------------
// Tab: Statistiche
// ---------------------------------------------------------------------------

async function loadStats() {
  const container = document.getElementById("stats-content");
  try {
    const data = await api("/api/stats");
    const g = data.global;

    let html = `<div class="stat-grid">
      ${statBox(g.leads_found, "Lead trovati")}
      ${statBox(g.leads_approved, "Approvati")}
      ${statBox(g.emails_sent, "Email inviate")}
      ${statBox(g.replies, "Risposte")}
      ${statBox(g.clients, "Clienti")}
      ${statBox(g.conversion_rate + "%", "Conversione")}
    </div>`;

    html += `<h3 class="section-title">Per categoria</h3>`;
    const cats = Object.entries(data.by_category);
    if (cats.length === 0) {
      html += `<p class="muted">Nessun dato ancora.</p>`;
    } else {
      cats.forEach(([cat, cs]) => {
        html += `<div class="stat-row">${cat}: ${cs.contacted} contatti, ${cs.replies} risposte, ${cs.clients} clienti</div>`;
      });
    }

    container.innerHTML = html;
  } catch (err) {
    console.error(err);
  }
}

function statBox(value, label) {
  return `<div class="stat-box"><div class="value">${value}</div><div class="label">${label}</div></div>`;
}

// ---------------------------------------------------------------------------
// Tab: Impostazioni
// ---------------------------------------------------------------------------

async function loadSettings() {
  const container = document.getElementById("settings-content");
  const pausePill = document.getElementById("pause-pill");
  try {
    const s = await api("/api/settings");
    pausePill.hidden = !s.paused;

    container.innerHTML = `
      <div class="settings-row"><span>Provider ricerca</span><span>${s.lead_provider}</span></div>
      <div class="settings-row"><span>Provider AI</span><span>${s.ai_provider}</span></div>
      <div class="settings-row"><span>Città default</span><span>${s.default_city}</span></div>
      <div class="settings-row"><span>Max email/giorno</span><span>${s.max_emails_per_day}</span></div>
      <div class="settings-row"><span>Max email/ora</span><span>${s.max_emails_per_hour}</span></div>
      <div class="settings-row"><span>Fascia oraria invio</span><span>${s.sending_hour_start}:00–${s.sending_hour_end}:00</span></div>
      <div class="pause-toggle">
        <button id="pause-toggle-btn" class="btn ${s.paused ? "btn-accent" : "btn-outline"} btn-block">
          ${s.paused ? "▶️ Riattiva invii" : "⏸ Metti in pausa invii"}
        </button>
      </div>
    `;

    document.getElementById("pause-toggle-btn").addEventListener("click", async () => {
      await api("/api/settings/pause", { method: "POST", body: JSON.stringify({ paused: !s.paused }) });
      loadSettings();
    });
  } catch (err) {
    console.error(err);
  }
}

// ---------------------------------------------------------------------------
// Avvio
// ---------------------------------------------------------------------------

checkSession();
