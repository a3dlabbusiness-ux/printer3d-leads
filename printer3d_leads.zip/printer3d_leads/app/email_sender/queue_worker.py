"""
Worker che gira periodicamente (via scheduler) e:
1. controlla se si può inviare ora (limiti, pausa, fascia oraria);
2. se sì, prende il prossimo messaggio in coda e lo invia;
3. aggiorna stato lead e messaggio;
4. notifica Telegram in caso di errore di invio.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Callable, Optional

from app.database.db import get_session
from app.database.models import EventLog, LeadStatus
from app.email_sender.smtp_sender import SmtpSendError, send_email
from app.services import queue_service

logger = logging.getLogger(__name__)


def process_queue_once(notify_error: Optional[Callable[[str], None]] = None) -> bool:
    """Prova a inviare al massimo UNA email (rispettando i limiti). Restituisce True se ha inviato."""
    with get_session() as session:
        can_send, reason = queue_service.can_send_now(session)
        if not can_send:
            logger.debug("Invio saltato: %s", reason)
            return False

        message = queue_service.get_next_queued_message(session)
        if not message:
            return False

        lead = message.lead
        try:
            send_email(to_email=message.to_email, subject=message.subject, body=message.body)
            message.status = "SENT"
            message.sent_at = datetime.utcnow()
            lead.status = LeadStatus.SENT
            lead.sent_at = message.sent_at
            session.add(
                EventLog(
                    event_type="EMAIL_SENT",
                    message=f"Email inviata a {message.to_email}",
                    lead_id=lead.id,
                )
            )
            logger.info("Email inviata con successo a %s (lead=%s)", message.to_email, lead.name)
            return True
        except SmtpSendError as exc:
            message.status = "FAILED"
            message.error = str(exc)
            lead.status = LeadStatus.ERROR
            lead.last_error = str(exc)
            session.add(
                EventLog(
                    event_type="EMAIL_FAILED",
                    message=f"Invio fallito verso {message.to_email}: {exc}",
                    lead_id=lead.id,
                )
            )
            logger.error("Invio fallito verso %s: %s", message.to_email, exc)
            if notify_error:
                notify_error(f"Invio fallito per '{lead.name}' ({message.to_email}): {exc}")
            return False
