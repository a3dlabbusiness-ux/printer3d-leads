"""
Entrypoint dell'applicazione.

Avvia:
1. il bot Telegram (comandi + bottoni di approvazione);
2. un job periodico che processa la coda email rispettando i limiti configurati;
3. un job periodico che controlla eventuali risposte via IMAP (se configurato).

Avvio:
    python legacy_telegram_main.py

NOTA: questa è l'interfaccia LEGACY basata su Telegram. L'interfaccia
principale del progetto ora è la web-app (vedi web_main.py e README).
Usa questo file solo se preferisci ancora controllare tutto da Telegram
invece che dalla PWA installata sull'iPhone. Richiede di installare anche
requirements-telegram-optional.txt.
"""
from __future__ import annotations

import logging

from telegram.ext import ContextTypes

from app.database.db import get_session, init_db
from app.email_sender.queue_worker import process_queue_once
from app.logging_config import setup_logging
from app.reply_checker.imap_checker import imap_configured, process_replies
from app.telegram_bot.bot import build_application, notify_admin_text

logger = logging.getLogger(__name__)

QUEUE_CHECK_INTERVAL_SECONDS = 60
REPLY_CHECK_INTERVAL_SECONDS = 300


async def job_process_queue(context: ContextTypes.DEFAULT_TYPE) -> None:
    def notify_error(msg: str):
        # notify_error viene chiamato in modo sincrono dal worker; schedula l'invio async
        context.application.create_task(notify_admin_text(context.bot, f"⚠️ {msg}"))

    try:
        process_queue_once(notify_error=notify_error)
    except Exception:
        logger.exception("Errore nel job di elaborazione coda email")


async def job_check_replies(context: ContextTypes.DEFAULT_TYPE) -> None:
    if not imap_configured():
        return
    try:
        with get_session() as session:
            updated_leads = process_replies(session)
        for lead in updated_leads:
            await notify_admin_text(
                context.bot,
                f"📩 *Nuova risposta ricevuta!*\n\n*{lead.name}* ({lead.email}) ha risposto.\n"
                f"Ho preparato una bozza di risposta: usa /recent per vederne lo stato.",
            )
    except Exception:
        logger.exception("Errore nel job di controllo risposte IMAP")


def main() -> None:
    setup_logging()
    logger.info("Inizializzazione database...")
    init_db()

    logger.info("Costruzione applicazione Telegram...")
    application = build_application()

    application.job_queue.run_repeating(
        job_process_queue, interval=QUEUE_CHECK_INTERVAL_SECONDS, first=10
    )
    application.job_queue.run_repeating(
        job_check_replies, interval=REPLY_CHECK_INTERVAL_SECONDS, first=30
    )

    logger.info("Bot avviato. In ascolto di comandi Telegram (Ctrl+C per fermare)...")
    application.run_polling(allowed_updates=["message", "callback_query"])


if __name__ == "__main__":
    main()
